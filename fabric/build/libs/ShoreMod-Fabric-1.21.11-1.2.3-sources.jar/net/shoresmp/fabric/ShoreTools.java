package net.shoresmp.fabric;

import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1109;
import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_3417;
import net.minecraft.class_412;
import net.minecraft.class_4185;
import net.minecraft.class_419;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.shoresmp.core.PunishmentMatcher;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Zoom, durability warnings, death locations and reconnecting. All purely client-side. */
public final class ShoreTools {
    private ShoreTools(){}
    private static final class_1304[] WATCHED={class_1304.field_6173,class_1304.field_6171,class_1304.field_6169,class_1304.field_6174,class_1304.field_6172,class_1304.field_6166};
    private static final DateTimeFormatter WHEN=DateTimeFormatter.ofPattern("MMM d, HH:mm",Locale.ROOT);

    // ------------------------------------------------------------------ zoom
    public static class_304 zoomKey;
    private static double zoom=1,zoomTarget=1,heldLevel;
    private static boolean wasZooming,toggled,zoomSetSmooth;
    private static long lastZoomFrame;

    private static boolean zooming(){
        var client=class_310.method_1551();Config c=ShoreClient.config;
        if(zoomKey==null||!c.zoomEnabled||client.field_1755!=null||client.field_1724==null)return false;
        return c.zoomToggle?toggled:zoomKey.method_1434();
    }
    /** Divisor applied to the rendered field of view. */
    public static double fovDivisor(){
        zoomTarget=wasZooming?heldLevel:1;
        long now=System.nanoTime();
        double dt=lastZoomFrame==0?1:Math.min(0.1,(now-lastZoomFrame)/1e9);lastZoomFrame=now;
        if(!ShoreClient.config.zoomSmooth)zoom=zoomTarget;
        else{zoom+=(zoomTarget-zoom)*Math.min(1,dt*14);if(Math.abs(zoom-zoomTarget)<0.01)zoom=zoomTarget;}
        return zoom;
    }
    /** @return true when the scroll was consumed to adjust zoom. */
    public static boolean scroll(double vertical){
        if(!zooming()||!ShoreClient.config.zoomScroll||vertical==0)return false;
        double step=1+ShoreClient.config.zoomScrollSpeed/100.0;
        heldLevel=Math.clamp(heldLevel*(vertical>0?step:1/step),1.5,50);
        return true;
    }
    /** Runs every client tick: toggle handling and the cinematic camera while zoomed. */
    private static void zoomTick(class_310 client){
        Config c=ShoreClient.config;
        while(zoomKey!=null&&zoomKey.method_1436())if(c.zoomToggle)toggled=!toggled;
        if(!c.zoomToggle||client.field_1724==null)toggled=c.zoomToggle&&toggled&&client.field_1724!=null;
        boolean active=zooming();
        if(active&&!wasZooming){
            heldLevel=c.zoomLevel;
            // smoothCameraEnabled is a runtime flag (never written to options.txt); only undo it if zoom set it.
            zoomSetSmooth=c.zoomCinematic&&!client.field_1690.field_1914;
            if(zoomSetSmooth)client.field_1690.field_1914=true;
            wasZooming=true;
        }else if(!active&&wasZooming){
            wasZooming=false;restoreZoomInput(client);
        }
    }
    /**
     * Multiplier for camera turning while zoomed: a fixed percentage (static) or in proportion to the
     * zoom (dynamic). Applied to the look movement itself, so the sensitivity setting is never changed.
     */
    public static double lookScale(){
        if(!wasZooming)return 1;
        Config c=ShoreClient.config;
        return c.zoomSensMode==0?c.zoomSensitivity/100.0:1/Math.max(1,heldLevel);
    }
    public static void restoreZoomInput(class_310 client){
        if(zoomSetSmooth){client.field_1690.field_1914=false;zoomSetSmooth=false;}
    }

    // ------------------------------------------------------------------ module toggle keys
    private static final Map<String,Boolean> keyWasDown=new HashMap<>();
    /** Toggle keys set on module pages: a fresh press while playing switches that module on or off. */
    private static void moduleKeysTick(class_310 client){
        var keys=ShoreClient.config.moduleKeys;
        if(keys.isEmpty())return;
        long window=client.method_22683().method_4490();
        for(var e:keys.entrySet()){
            var key=net.minecraft.class_3675.method_15981(e.getValue());
            boolean down=key.method_1442()==net.minecraft.class_3675.class_307.field_1672
                ?org.lwjgl.glfw.GLFW.glfwGetMouseButton(window,key.method_1444())==org.lwjgl.glfw.GLFW.GLFW_PRESS
                :net.minecraft.class_3675.method_15987(client.method_22683(),key.method_1444());
            boolean was=keyWasDown.getOrDefault(e.getKey(),false);
            keyWasDown.put(e.getKey(),down);
            if(down&&!was&&client.field_1755==null&&client.field_1724!=null){
                String status=ShoreScreen.toggleById(e.getKey());
                if(status!=null)client.field_1705.method_1758(class_2561.method_43470(status),false);
            }
        }
    }

    // ------------------------------------------------------------------ CPS
    private static final java.util.ArrayDeque<Long> leftClicks=new java.util.ArrayDeque<>(),rightClicks=new java.util.ArrayDeque<>();
    public static void click(int button){
        long now=System.currentTimeMillis();
        if(button==0)leftClicks.addLast(now);else if(button==1)rightClicks.addLast(now);
    }
    public static int cps(boolean left){
        var q=left?leftClicks:rightClicks;long cutoff=System.currentTimeMillis()-1000;
        while(!q.isEmpty()&&q.peekFirst()<cutoff)q.pollFirst();
        return q.size();
    }

    // ------------------------------------------------------------------ per-tick checks
    private static final Map<class_1304,class_1792> lastItem=new EnumMap<>(class_1304.class);
    private static final Map<class_1304,Integer> lastPct=new EnumMap<>(class_1304.class);
    private static boolean wasDead;

    public static void tick(class_310 client){
        zoomTick(client);
        moduleKeysTick(client);
        var player=client.field_1724;
        if(player==null){lastItem.clear();lastPct.clear();wasDead=false;return;}
        Config c=ShoreClient.config;
        if(c.durabilityAlert)for(class_1304 slot:WATCHED){
            class_1799 s=player.method_6118(slot);
            if(s.method_7960()||!s.method_7963()||s.method_7936()<=0){lastItem.remove(slot);lastPct.remove(slot);continue;}
            int left=s.method_7936()-s.method_7919(),pct=left*100/s.method_7936();
            Integer before=lastPct.get(slot);
            if(lastItem.get(slot)==s.method_7909()&&before!=null&&before>c.durabilityThreshold&&pct<=c.durabilityThreshold){
                if(c.durabilitySound)client.method_1483().method_4873(class_1109.method_47978(class_3417.field_14622,0.6f));
                if(c.durabilityChat)ShoreClient.tell(s.method_7964().getString()+" has "+left+" durability left");
                else client.field_1705.method_1758(class_2561.method_43470("⚠ ").method_54663(0xFFB45A)
                    .method_10852(s.method_7964().method_27661().method_54663(0xFFFFFF)).method_10852(class_2561.method_43470(" has "+left+" durability left").method_54663(0xFFB45A)),false);
            }
            lastItem.put(slot,s.method_7909());lastPct.put(slot,pct);
        }
        boolean dead=player.method_29504();
        if(dead&&!wasDead&&c.deathLog&&client.field_1687!=null){
            String dim=ShoreHud.title(client.field_1687.method_27983().method_29177().method_12832());
            String where=player.method_31477()+" "+player.method_31478()+" "+player.method_31479();
            String server=lastServer==null?"Singleplayer":lastServer.field_3752;
            c.deaths.addFirst(LocalDateTime.now().format(WHEN)+"  ·  "+dim+"  ·  "+where+"  ·  "+server);
            c.save();
            if(c.deathAnnounce)ShoreClient.tell("You died at "+where+" in "+dim+". Use /shore deaths for recent deaths.");
        }
        wasDead=dead;
    }

    // ------------------------------------------------------------------ reconnect
    private static class_642 lastServer;
    public static volatile String lastDisconnectReason="";
    private static int autoAttempts;

    public static void joined(class_310 client){
        class_642 info=client.method_1558();
        if(info!=null&&!info.method_52811())lastServer=info;
        autoAttempts=0;lastDisconnectReason="";
    }
    private static void reconnect(class_310 client){
        if(lastServer==null)return;
        class_412.method_36877(new class_500(new class_442()),client,class_639.method_2950(lastServer.field_3761),lastServer,false,null);
    }
    public static void register(){
        ScreenEvents.AFTER_INIT.register((client,screen,w,h)->{
            if(!(screen instanceof class_419)||lastServer==null||!ShoreClient.config.reconnectButton)return;
            List<class_339> buttons=Screens.getButtons(screen);
            // Stack below the lowest existing button ("Back to server list").
            int bx=w/2-100,by=-1;
            for(class_339 b:buttons)if(b.method_46427()+b.method_25364()+4>by){bx=b.method_46426()+(b.method_25368()-200)/2;by=b.method_46427()+b.method_25364()+4;}
            if(by<0)by=h/2+40;
            Config c=ShoreClient.config;
            String reason=lastDisconnectReason==null?"":lastDisconnectReason;
            boolean auto=c.autoReconnect&&autoAttempts<5&&!PunishmentMatcher.matches(reason,c.punishmentPhrases);
            final int[] ticks={auto?c.autoReconnectDelay*20:-1};
            class_4185 button=class_4185.method_46430(label(lastServer,ticks[0]),b->{ticks[0]=-1;reconnect(client);}).method_46434(bx,by,200,20).method_46431();
            buttons.add(button);
            final class_4185[] cancel={null};
            if(auto){
                cancel[0]=class_4185.method_46430(class_2561.method_43470("Cancel auto-reconnect"),b->{ticks[0]=-1;button.method_25355(label(lastServer,-1));b.field_22764=false;}).method_46434(bx,by+24,200,20).method_46431();
                buttons.add(cancel[0]);
            }
            ScreenEvents.afterTick(screen).register(s->{
                if(ticks[0]<0)return;
                if(--ticks[0]<=0){ticks[0]=-1;autoAttempts++;reconnect(client);return;}
                if(ticks[0]%20==0)button.method_25355(label(lastServer,ticks[0]));
            });
        });
    }
    private static class_2561 label(class_642 info,int ticks){
        String name=info.field_3752==null||info.field_3752.isBlank()?info.field_3761:info.field_3752;
        if(name.length()>22)name=name.substring(0,21)+"...";
        if(ticks<0)return class_2561.method_43470("Reconnect to "+name);
        return class_2561.method_43470("Reconnecting in "+Math.max(1,(ticks+19)/20)+"s...");
    }
}
