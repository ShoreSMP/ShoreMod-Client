package net.shoresmp.fabric;

import com.mojang.brigadier.arguments.*;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.class_310;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.shoresmp.core.*;
import java.util.*;

public final class ShoreCommands {
    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registry) -> {
            dispatcher.register(ClientCommandManager.literal("shore").executes(ctx -> {
                ShoreClient.openNextTick(()->new ShoreScreen(null)); return 1;
            }).then(ClientCommandManager.literal("status").executes(ctx->{ShoreClient.tell(ShoreClient.presenceStatus());ShoreClient.tell("Badges: "+ShoreClient.config.badges+", nametags: "+ShoreClient.config.badgeNametags+", tab: "+ShoreClient.config.badgeTab);ShoreClient.resyncPresence();return 1;})).then(ClientCommandManager.literal("deaths").executes(ctx -> deaths())
                .then(ClientCommandManager.literal("clear").executes(ctx -> {
                    ShoreClient.config.deaths.clear(); ShoreClient.config.save(); ShoreClient.tell("Death history cleared."); return 1;
                }))));
            dispatcher.register(ClientCommandManager.literal("paycancel").executes(ctx -> { ShoreClient.payments.cancel(true); return 1; }));
            dispatcher.register(ClientCommandManager.literal("paystatus").executes(ctx -> { ShoreClient.tell(ShoreClient.payments.status()); return 1; }));
            dispatcher.register(ClientCommandManager.literal("payall").then(ClientCommandManager.argument("amount", StringArgumentType.word())
                .executes(ctx -> plan("all", StringArgumentType.getString(ctx,"amount"), 0))));
            dispatcher.register(ClientCommandManager.literal("splitpay").then(ClientCommandManager.argument("total", StringArgumentType.word())
                .executes(ctx -> plan("split", StringArgumentType.getString(ctx,"total"), 0))));
            dispatcher.register(ClientCommandManager.literal("payrandom").then(ClientCommandManager.argument("amount", StringArgumentType.word())
                .executes(ctx -> plan("random", StringArgumentType.getString(ctx,"amount"), 1))
                .then(ClientCommandManager.argument("count", IntegerArgumentType.integer(1,10000))
                    .executes(ctx -> plan("random", StringArgumentType.getString(ctx,"amount"), IntegerArgumentType.getInteger(ctx,"count"))))));
            dispatcher.register(ClientCommandManager.literal("payrain").then(ClientCommandManager.argument("total", StringArgumentType.word())
                .then(ClientCommandManager.argument("winners", IntegerArgumentType.integer(1,10000))
                    .executes(ctx -> plan("rain", StringArgumentType.getString(ctx,"total"), IntegerArgumentType.getInteger(ctx,"winners"))))));
            // /modlist intentionally stays a server command. The plugin checks developer access.
        });
    }
    private static int deaths() {
        var deaths = ShoreClient.config.deaths;
        if (deaths.isEmpty()) { ShoreClient.tell("No deaths recorded yet."); return 1; }
        ShoreClient.tell("Recent deaths (newest first):");
        for (int i = 0; i < deaths.size(); i++) ShoreClient.tell((i + 1) + ".  " + deaths.get(i));
        return 1;
    }
    private static int plan(String mode, String value, int count) {
        try {
            var client = class_310.method_1551();
            if (client.field_1724 == null || client.method_1562() == null || ShoreClient.lastRosterAt == 0)
                throw new IllegalArgumentException("The ShoreMod plugin has not supplied an online roster.");
            if (ShoreClient.payments.running()) throw new IllegalArgumentException("Use /paycancel before creating another payment queue.");
            var users = new ArrayList<>(ShoreClient.roster.users().values().stream()
                .filter(u -> !u.id().equals(client.field_1724.method_5667()))
                .filter(u -> client.method_1562().method_2871(u.id()) != null)
                .sorted(Comparator.comparing(Wire.User::name)).toList());
            var amount = Payments.amount(value);
            if (mode.equals("random") || mode.equals("rain")) {
                if (count > users.size()) throw new IllegalArgumentException("Only " + users.size() + " eligible players are in tab.");
                Collections.shuffle(users); users = new ArrayList<>(users.subList(0,count));
            }
            var payments = switch (mode) {
                case "split" -> Payments.split(users,amount,null);
                case "rain" -> Payments.split(users,amount,new Random());
                default -> Payments.each(users,amount);
            };
            var preview=new PaymentScreen(null, payments, client.method_1562());
            ShoreClient.openNextTick(()->preview);
            return 1;
        } catch (IllegalArgumentException e) { ShoreClient.tellError(e.getMessage()); return 0; }
    }
}
