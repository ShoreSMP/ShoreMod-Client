package net.shoresmp.fabric;

import java.util.List;
import net.minecraft.class_310;

/** Development-only integration checks, invoked by the compatibility smoke-test property. */
public final class ShoreSettingsChecks {
    private ShoreSettingsChecks(){}
    private static void check(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    @SuppressWarnings("unchecked")
    private static ShoreScreen.Row row(ShoreScreen screen,String title)throws ReflectiveOperationException{
        var field=ShoreScreen.class.getDeclaredField("rows");field.setAccessible(true);
        return ((List<ShoreScreen.Row>)field.get(screen)).stream().filter(r->r.title.equals(title)).findFirst().orElseThrow();
    }
    private static void confirm(ShoreScreen screen,ShoreScreen.Input input,String value)throws ReflectiveOperationException{
        input.set(value,true);
        var focus=ShoreScreen.class.getDeclaredField("focused");focus.setAccessible(true);focus.set(screen,input);
        var commit=ShoreScreen.class.getDeclaredMethod("finishInput",boolean.class);commit.setAccessible(true);commit.invoke(screen,true);
    }
    public static void run(){
        Config c=ShoreClient.config;
        boolean enabled=c.fullbright;int strength=c.fullbrightStrength,size=c.hudSize("fps"),color=c.crosshairCustomColor,mode=c.crosshairColor;
        try{
            c.fullbright=false;double vanilla=class_310.method_1551().field_1690.method_42473().method_41753();
            var screen=new ShoreScreen(null);screen.showModule("fullbright");
            var numeric=row(screen,"Brightness boost").input;
            confirm(screen,numeric,"37");check(c.fullbrightStrength==37,"custom brightness is applied");
            numeric.set("101",true);check(c.fullbrightStrength==37&&!numeric.validation.apply(numeric.text).isEmpty(),"over-limit input is rejected");
            numeric.set("NaN",true);check(c.fullbrightStrength==37,"non-numeric input is rejected");
            c.fullbright=true;
            double bright=class_310.method_1551().field_1690.method_42473().method_41753();
            check(bright>vanilla&&bright<=16,"fullbright reaches the real game gamma getter");
            class_310.method_1551().field_1690.method_1640();
            String saved=java.nio.file.Files.readString(class_310.method_1551().field_1697.toPath().resolve("options.txt"));
            double stored=saved.lines().filter(line->line.startsWith("gamma:")).mapToDouble(line->Double.parseDouble(line.substring(6))).findFirst().orElseThrow();
            check(stored==vanilla,"saving game options cannot persist boosted gamma");
            check(class_310.method_1551().field_1690.method_42473().method_41753()==bright,"fullbright resumes after options save");
            c.fullbright=false;
            check(class_310.method_1551().field_1690.method_42473().method_41753()==vanilla,"fullbright restores the unchanged vanilla value");
            screen.showModule("fps");confirm(screen,row(screen,"Element size").input,"173");
            check(c.hudSize("fps")==173,"typed values do not snap to slider presets");
            screen.showModule("crosshair");var rgb=row(screen,"Custom crosshair color").input;
            rgb.set("#12AB34",true);check(c.crosshairCustomColor==0x12AB34&&c.crosshairColor==6,"custom hex color is applied");
            rgb.set("#GGGGGG",true);check(c.crosshairCustomColor==0x12AB34,"invalid hex cannot overwrite a color");
            int[] painted=c.crosshairPaint.clone();String image=c.crosshairImage;int imageMode=c.crosshairMode,imageSize=c.crosshairImageSize;
            boolean crosshair=c.crosshair,tint=c.crosshairTint;
            var file=ShoreHud.CrosshairImage.folder().resolve("painted-crosshair.png");byte[] previous=java.nio.file.Files.exists(file)?java.nio.file.Files.readAllBytes(file):null;
            try{
                var editor=new CrosshairEditorScreen(screen);
                var field=CrosshairEditorScreen.class.getDeclaredField("canvas");field.setAccessible(true);
                var canvas=(net.shoresmp.core.PixelCanvas)field.get(editor);canvas.begin();canvas.line(15,15,16,16,0xFF50A7FF);canvas.end();
                var save=CrosshairEditorScreen.class.getDeclaredMethod("save");save.setAccessible(true);save.invoke(editor);
                check(c.crosshair&&c.crosshairMode==1&&!c.crosshairTint,"painted crosshair becomes active without image tint");
                check(javax.imageio.ImageIO.read(file.toFile()).getRGB(15,15)==0xFF50A7FF,"painted color survives PNG save");
                check(ShoreHud.CrosshairImage.texture(c.crosshairImage)!=null,"painted PNG loads into the real texture manager");
            }finally{
                c.crosshairPaint=painted;c.crosshairImage=image;c.crosshairMode=imageMode;c.crosshairImageSize=imageSize;c.crosshair=crosshair;c.crosshairTint=tint;
                if(previous==null)java.nio.file.Files.deleteIfExists(file);else java.nio.file.Files.write(file,previous);
                ShoreHud.CrosshairImage.invalidate();
            }
            ShoreClient.LOG.info("SHORE_CUSTOM_SETTINGS_PASS");
        }catch(ReflectiveOperationException|java.io.IOException e){throw new IllegalStateException(e);}
        finally{c.fullbright=enabled;c.fullbrightStrength=strength;c.hudSizes.put("fps",size);c.crosshairCustomColor=color;c.crosshairColor=mode;c.save();}
    }
}
