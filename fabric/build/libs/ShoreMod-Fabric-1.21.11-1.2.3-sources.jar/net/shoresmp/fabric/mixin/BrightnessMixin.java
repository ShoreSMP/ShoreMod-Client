package net.shoresmp.fabric.mixin;

import net.shoresmp.fabric.ShoreClient;
import net.minecraft.class_310;
import net.minecraft.class_7172;
import net.shoresmp.core.SettingValues;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** A temporary render-time brightness override; never writes vanilla's gamma setting. */
@Mixin(class_7172.class)
public abstract class BrightnessMixin {
    @Inject(method="getValue",at=@At("RETURN"),cancellable=true)
    private void shore$brightness(CallbackInfoReturnable<Object> cir){
        var config=ShoreClient.config;
        if(config==null||!config.fullbright||config.fullbrightStrength==0||net.shoresmp.fabric.BrightnessState.saving())return;
        var client=class_310.method_1551();
        if(client==null||client.field_1690==null||(Object)this!=client.field_1690.method_42473())return;
        if(cir.getReturnValue() instanceof Double vanilla)
            cir.setReturnValue(SettingValues.brightness(vanilla,config.fullbrightStrength));
    }
}
