package net.shoresmp.fabric.mixin;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import java.util.List;
import java.util.Set;
import net.minecraft.class_11642;
import net.minecraft.class_2960;
import net.minecraft.class_380;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/** Smooth only ShoreMod's oversampled UI fonts; leave vanilla text and logos untouched. */
@Mixin(class_11642.class)
public abstract class GlyphBakerMixin {
    @Shadow @Final private class_2960 fontId;
    @Shadow @Final private List<class_380> glyphAtlases;
    @Unique private static final Set<String> SHORE_UI_FONTS=Set.of("ui","ui-bold","ui-small","heading");
    @Inject(method="bake",at=@At("RETURN"))
    private void shore$smoothUiAtlas(CallbackInfoReturnable<?> ci){
        if(!fontId.method_12836().equals("shoremod"))return;
        if(!SHORE_UI_FONTS.contains(fontId.method_12832())&&!fontId.method_12832().startsWith("px_"))return;
        var linear=RenderSystem.getSamplerCache().method_75294(FilterMode.LINEAR);
        for(var atlas:glyphAtlases)if(atlas.method_75484()!=linear)
            ((TextureSamplerAccessor)(Object)atlas).shore$setSampler(linear);
    }
}
