package net.shoresmp.fabric.mixin;
import net.minecraft.class_2663;
import net.minecraft.class_634;
import net.shoresmp.fabric.ShorePvp;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_634.class)
public abstract class EntityStatusMixin {
    // After forceMainThread, so this only runs once, on the client thread, with the world available.
    @Inject(method="onEntityStatus",at=@At(value="INVOKE",target="Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;Lnet/minecraft/network/PacketApplyBatcher;)V",shift=At.Shift.AFTER))
    private void shore$totemPops(class_2663 packet,CallbackInfo ci){
        var client=net.minecraft.class_310.method_1551();
        if(client.field_1687==null)return;
        var entity=packet.method_11469(client.field_1687);
        if(entity!=null)ShorePvp.onEntityStatus(entity,packet.method_11470());
    }
}
