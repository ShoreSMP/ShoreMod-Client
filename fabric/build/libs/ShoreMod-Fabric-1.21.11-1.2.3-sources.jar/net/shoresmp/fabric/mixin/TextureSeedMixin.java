package net.shoresmp.fabric.mixin;
import net.minecraft.class_2338;
import net.minecraft.class_4970;
import net.shoresmp.fabric.AntiLeakTextures;
import net.shoresmp.fabric.ShoreClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(class_4970.class_4971.class)
public abstract class TextureSeedMixin {
    @Inject(method="getRenderingSeed",at=@At("RETURN"),cancellable=true)
    private void shore$privateTextureSeed(class_2338 pos,CallbackInfoReturnable<Long> ci){
        if(ShoreClient.config!=null&&ShoreClient.config.antiLeakTextures)
            ci.setReturnValue(AntiLeakTextures.seed(ci.getReturnValue()));
    }
}
