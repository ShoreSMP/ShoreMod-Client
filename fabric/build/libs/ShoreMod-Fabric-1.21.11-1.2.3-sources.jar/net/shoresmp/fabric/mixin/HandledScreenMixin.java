package net.shoresmp.fabric.mixin;

import net.minecraft.class_11909;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1734;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2480;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import net.minecraft.item.*;
import net.minecraft.screen.*;
import net.minecraft.screen.slot.*;
import net.shoresmp.fabric.Config;
import net.shoresmp.fabric.ShoreClient;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
import java.util.*;

/**
 * Mouse Tweaks-style inventory controls, done entirely with ordinary slot clicks:
 *  - Right-click drag with a stack: drop one item into every slot you sweep over (again on revisits).
 *  - Left-click drag with a stack, starting on a matching stack: collect every matching stack you sweep over.
 *    (Starting on an empty slot keeps vanilla's even-split drag.)
 *  - Shift + left-click drag: quick-move every stack you sweep over, with or without a held item.
 *  - Scroll over an item: down sends one item to the other inventory, up pulls one matching item back.
 *  - Right-click a shulker box with an empty cursor to preview it.
 * Held buttons are read from Minecraft's own mouse state each frame as well as from drag events.
 */
@Mixin(class_465.class)
public abstract class HandledScreenMixin extends class_437 {
    @Shadow @Final protected class_1703 handler;
    @Shadow private class_1735 getSlotAt(double x,double y){throw new AssertionError();}
    @Unique private static final int SHORE_NONE=0,SHORE_PLACE=1,SHORE_MOVE=2,SHORE_COLLECT=3;
    @Shadow protected class_1735 focusedSlot;
    @Shadow protected abstract void onMouseClick(class_1735 slot,int slotId,int button,class_1713 type);
    @Unique private static final boolean SHORE_EXTERNAL_TWEAKS=net.fabricmc.loader.api.FabricLoader.getInstance().isModLoaded("mousetweaks");
    @Unique private boolean shore$special(class_1735 slot){return (Object)this instanceof net.minecraft.class_481&&(slot==null||!(slot.field_7871 instanceof class_1661));}
    @Unique private int shore$mode=SHORE_NONE;
    @Unique private class_1735 shore$lastSlot;
    @Unique private final Set<class_1735> shore$visited=new HashSet<>();
    @Unique private class_1799 shore$filter=class_1799.field_8037;
    @Unique private double shore$lx,shore$ly;
    @Shadow protected int x;
    @Shadow protected int y;
    @Shadow protected abstract boolean isClickOutsideBounds(double mouseX,double mouseY,int left,int top);
    protected HandledScreenMixin(class_2561 title){super(title);}

    @Unique private static Config shore$cfg(){return ShoreClient.config;}
    @Unique private static boolean shore$on(boolean sub){Config c=shore$cfg();return !SHORE_EXTERNAL_TWEAKS&&c!=null&&c.mouseTweaks&&sub;}
    @Unique private void shore$click(class_1735 slot,int button,class_1713 type){
        var client=class_310.method_1551();
        if(client.field_1724==null||client.field_1761==null)return;
        onMouseClick(slot,slot.field_7874,button,type); // Preserve the screen's own creative/special-slot handling.
    }

    // ------------------------------------------------------------------ press
    @Inject(method="mouseClicked",at=@At("HEAD"),cancellable=true)
    private void shore$press(class_11909 click,boolean doubled,CallbackInfoReturnable<Boolean> cir){
        double mx=click.comp_4798(),my=click.comp_4799();int button=click.method_74245();
        Config c=shore$cfg();
        class_1735 slot=getSlotAt(mx,my);
        if(shore$special(slot)){shore$reset();return;}
        if(c==null)return;
        class_1799 cursor=handler.method_34255();
        // A sweep may start anywhere inside the inventory window, not only on a slot. Presses outside
        // the window keep vanilla behaviour (e.g. throwing the held stack).
        boolean inside=slot!=null||!isClickOutsideBounds(mx,my,x,y);
        shore$visited.clear();shore$lastSlot=slot;shore$lx=mx;shore$ly=my;
        shore$filter=cursor.method_7960()?class_1799.field_8037:cursor.method_7972();
        boolean shift=click.method_74239();
        shore$mode=SHORE_NONE;
        if(!inside)return;
        if(button==1&&!shift&&!cursor.method_7960()&&shore$on(c.tweakRmb)){
            shore$mode=SHORE_PLACE;if(slot!=null)shore$place(slot);cir.setReturnValue(true);
        }else if(button==0&&shift&&shore$on(c.tweakShift)){
            shore$mode=SHORE_MOVE;
            if(slot!=null){
                shore$visited.add(slot);
                // On a slot, vanilla performs this first shift-click itself (keeps shift+double-click "move all").
                if(!shore$matches(slot)){cir.setReturnValue(true);shore$visited.remove(slot);}
            }else cir.setReturnValue(true);
        }else if(button==0&&!shift&&!cursor.method_7960()&&shore$on(c.tweakLmb)){
            if(slot==null){shore$mode=SHORE_COLLECT;cir.setReturnValue(true);}
            else if(slot.method_7681()&&class_1799.method_31577(slot.method_7677(),cursor)){
                shore$mode=SHORE_COLLECT;shore$visited.add(slot);shore$collect(slot);cir.setReturnValue(true);
            } // pressing on an empty or different slot keeps vanilla's place / even-split drag
        }
    }
    /** With an item on the cursor, shift-sweeps only move stacks of that item. */
    @Unique private boolean shore$matches(class_1735 slot){
        return slot.method_7681()&&(shore$filter.method_7960()||class_1799.method_31577(slot.method_7677(),shore$filter));
    }

    // ------------------------------------------------------------------ drag
    @Inject(method="mouseDragged",at=@At("HEAD"),cancellable=true)
    private void shore$drag(class_11909 click,double dx,double dy,CallbackInfoReturnable<Boolean> cir){
        if(shore$mode==SHORE_NONE)return;
        shore$step(click.comp_4798(),click.comp_4799());
        cir.setReturnValue(true);
    }
    // Minecraft does not record a button as held when a screen consumes the press (Mouse returns
    // early), so the sweep stays active until our own release handler sees the button go up.
    // Polling the cursor each frame catches fast sweeps that skip drag events.
    // renderMain, not render: recipe-book screens (inventory, crafting table, furnace) override
    // render() without calling it, but every handled screen draws through renderMain.
    @Inject(method="renderMain",at=@At("HEAD"))
    private void shore$poll(class_332 ctx,int mx,int my,float delta,CallbackInfo ci){
        if(shore$mode==SHORE_NONE)return;
        var mouse=class_310.method_1551().field_1729;var window=class_310.method_1551().method_22683();
        shore$step(mouse.method_68879(window),mouse.method_68883(window));
    }
    @Inject(method="removed",at=@At("HEAD"),require=0)
    private void shore$closed(CallbackInfo ci){shore$reset();}
    @Inject(method="mouseReleased",at=@At("HEAD"),cancellable=true)
    private void shore$release(class_11909 click,CallbackInfoReturnable<Boolean> cir){
        int button=click.method_74245();
        if((shore$mode==SHORE_PLACE&&button==1)||(shore$mode==SHORE_COLLECT&&button==0)){shore$reset();cir.setReturnValue(true);}
        else if(shore$mode==SHORE_MOVE&&button==0)shore$reset(); // vanilla still handles double-click move-all
    }
    @Unique private void shore$reset(){shore$mode=SHORE_NONE;shore$lastSlot=null;shore$visited.clear();}
    /**
     * Follows the cursor's path since the last update in small steps, so a fast sweep still visits
     * every slot it crosses instead of jumping over some of them.
     */
    @Unique private void shore$step(double mx,double my){
        double dx=mx-shore$lx,dy=my-shore$ly;
        if(dx==0&&dy==0)return;
        int n=Math.min(256,Math.max(1,(int)Math.ceil(Math.hypot(dx,dy)/3)));
        for(int i=1;i<=n&&shore$mode!=SHORE_NONE;i++)shore$visit(getSlotAt(shore$lx+dx*i/n,shore$ly+dy*i/n));
        shore$lx=mx;shore$ly=my;
    }
    @Unique private void shore$visit(class_1735 slot){
        if(slot==shore$lastSlot)return;
        shore$lastSlot=slot;
        if(slot==null||shore$special(slot))return;
        switch(shore$mode){
            case SHORE_PLACE->shore$place(slot);
            case SHORE_MOVE->{if(shore$matches(slot)&&shore$visited.add(slot))shore$quickMove(slot);}
            case SHORE_COLLECT->{if(shore$visited.add(slot))shore$collect(slot);}
            default->{}
        }
    }

    // ------------------------------------------------------------------ actions
    @Unique private void shore$place(class_1735 slot){
        var client=class_310.method_1551();var cursor=handler.method_34255();
        if(client.field_1724==null||cursor.method_7960()||!slot.method_7682()||!slot.method_7680(cursor))return;
        var stack=slot.method_7677();
        if(!stack.method_7960()&&(!class_1799.method_31577(stack,cursor)||stack.method_7947()>=slot.method_7676(cursor)))return;
        shore$click(slot,1,class_1713.field_7790);
    }
    @Unique private void shore$quickMove(class_1735 slot){
        var client=class_310.method_1551();
        if(client.field_1724==null||!slot.method_7682()||!slot.method_7674(client.field_1724))return;
        shore$click(slot,0,class_1713.field_7794);
    }
    /** Pull a matching stack into the cursor: merge the cursor into the slot, then pick the combined stack up. */
    @Unique private void shore$collect(class_1735 slot){
        var client=class_310.method_1551();var cursor=handler.method_34255();var stack=slot.method_7677();
        if(client.field_1724==null||cursor.method_7960()||stack.method_7960()||!slot.method_7682()||!slot.method_7674(client.field_1724))return;
        if(!class_1799.method_31577(stack,cursor))return;
        if(cursor.method_7947()+stack.method_7947()>Math.min(cursor.method_7914(),slot.method_7676(cursor)))return; // would not fit in one stack
        if(!slot.method_7680(cursor))return;
        shore$click(slot,0,class_1713.field_7790);
        shore$click(slot,0,class_1713.field_7790);
    }

    // ------------------------------------------------------------------ wheel
    @Inject(method="mouseScrolled",at=@At("HEAD"),cancellable=true)
    private void shore$wheel(double mx,double my,double horizontal,double vertical,CallbackInfoReturnable<Boolean> cir){
        Config c=shore$cfg();
        if((Object)this instanceof net.minecraft.class_481)return;
        if(vertical==0||!shore$on(c!=null&&c.tweakWheel)||!handler.method_34255().method_7960())return;
        class_1735 slot=getSlotAt(mx,my);
        if(slot==null||!slot.method_7682())return;
        boolean done=vertical<0?shore$pushOne(slot):shore$pullOne(slot);
        if(done||slot.method_7681())cir.setReturnValue(true);
    }
    @Unique private List<class_1735> shore$otherSide(class_1735 from){
        var out=new ArrayList<class_1735>();
        boolean playerOnly=handler instanceof class_1723;
        boolean fromHotbar=from.field_7871 instanceof class_1661&&from.method_34266()<9;
        for(class_1735 s:handler.field_7761){
            if(s==from||!s.method_7682()||s instanceof class_1734)continue;
            if(playerOnly){
                // Inventory screen: move between the hotbar and the main inventory.
                if(!(s.field_7871 instanceof class_1661)||s.method_34266()>=36)continue;
                if(fromHotbar==(s.method_34266()<9))continue;
            }else if(s.field_7871==from.field_7871)continue;
            out.add(s);
        }
        return out;
    }
    @Unique private boolean shore$pushOne(class_1735 from){
        var client=class_310.method_1551();var stack=from.method_7677();
        if(stack.method_7960()||client.field_1724==null||!from.method_7674(client.field_1724))return false;
        class_1735 target=null;
        for(class_1735 s:shore$otherSide(from))if(s.method_7681()&&class_1799.method_31577(s.method_7677(),stack)&&s.method_7677().method_7947()<s.method_7676(stack)&&s.method_7680(stack)){target=s;break;}
        if(target==null)for(class_1735 s:shore$otherSide(from))if(!s.method_7681()&&s.method_7680(stack)){target=s;break;}
        if(target==null)return false;
        shore$click(from,0,class_1713.field_7790);   // pick up the stack
        shore$click(target,1,class_1713.field_7790); // drop one
        shore$click(from,0,class_1713.field_7790);   // put the rest back
        return true;
    }
    @Unique private boolean shore$pullOne(class_1735 into){
        var client=class_310.method_1551();var here=into.method_7677();
        if(here.method_7960()||client.field_1724==null||here.method_7947()>=into.method_7676(here))return false;
        class_1735 source=null;
        for(class_1735 s:shore$otherSide(into))if(s.method_7681()&&class_1799.method_31577(s.method_7677(),here)&&s.method_7674(client.field_1724)){source=s;break;}
        if(source==null)return false;
        shore$click(source,0,class_1713.field_7790);
        shore$click(into,1,class_1713.field_7790);
        shore$click(source,0,class_1713.field_7790);
        return true;
    }

    // ------------------------------------------------------------------ shulker preview
    /** Hovering a shulker box (holding Shift, or always) shows its 27 slots instead of the text tooltip. */
    @Inject(method="drawMouseoverTooltip",at=@At("HEAD"),cancellable=true)
    private void shore$shulkerTooltip(class_332 ctx,int mx,int my,CallbackInfo ci){
        Config c=shore$cfg();
        if(c==null||!c.shulkerPreview||focusedSlot==null||!handler.method_34255().method_7960())return;
        class_1799 stack=focusedSlot.method_7677();
        if(!(stack.method_7909() instanceof class_1747 block)||!(block.method_7711() instanceof class_2480 box))return;
        if(c.shulkerMode==0){
            long w=class_310.method_1551().method_22683().method_4490();
            if(GLFW.glfwGetKey(w,GLFW.GLFW_KEY_LEFT_SHIFT)!=GLFW.GLFW_PRESS&&GLFW.glfwGetKey(w,GLFW.GLFW_KEY_RIGHT_SHIFT)!=GLFW.GLFW_PRESS)return;
        }
        ci.cancel();
        var items=net.minecraft.class_2371.method_10213(27,class_1799.field_8037);
        stack.method_58695(class_9334.field_49622,class_9288.field_49334).method_57492(items);
        // Size, background, border and title are all configurable on the Shulker Preview page.
        float sc=c.shulkerScale/100f;
        int titleH=c.shulkerTitle?13:0,pw=9*18+10,ph=3*18+9+titleH;
        float sw=pw*sc,sh=ph*sc;
        float x=mx+12,y=my-12;
        if(x+sw>field_22789-4)x=mx-12-sw;
        y=Math.clamp(y,4,Math.max(4,field_22790-sh-4));
        var dye=box.method_10528();
        int border=switch(c.shulkerBorderMode){
            case 0->dye!=null?0xFF000000|dye.method_7787():0xFF8E5CC0; // undyed shulkers are purple
            case 1->0xFF000000|c.accent;
            default->0;
        };
        int bg=(Math.round(c.shulkerBgOpacity*2.55f)<<24)|0x101216;
        var m=ctx.method_51448();m.pushMatrix();m.translate(x,y);m.scale(sc,sc);
        if(border!=0){ctx.method_25294(1,0,pw-1,ph,border);ctx.method_25294(0,1,pw,ph-1,border);}
        ctx.method_25294(2,1,pw-2,ph-1,bg);ctx.method_25294(1,2,pw-1,ph-2,bg);
        if(c.shulkerTitle)ctx.method_27535(field_22793,stack.method_7964(),6,6,0xFFFFFFFF);
        for(int i=0;i<27;i++){
            int sx=5+i%9*18,sy=5+titleH+i/9*18;
            if(c.shulkerEmptySlots)ctx.method_25294(sx,sy,sx+17,sy+17,0x22FFFFFF);
            class_1799 item=items.get(i);
            if(!item.method_7960()){ctx.method_51427(item,sx,sy);ctx.method_51431(field_22793,item,sx,sy);}
        }
        m.popMatrix();
    }
}
