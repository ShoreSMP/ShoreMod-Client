package net.shoresmp.fabric.mixin;
import net.minecraft.class_8673;
import net.minecraft.class_9812;
import net.shoresmp.fabric.ShoreClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(class_8673.class)
public abstract class DisconnectMixin {
    @Inject(method="onDisconnected",at=@At("HEAD"))
    private void shore$disconnect(class_9812 info,CallbackInfo ci){
        String reason=info.comp_2853().getString();
        net.shoresmp.fabric.ShoreTools.lastDisconnectReason=reason;
        if(ShoreClient.recorder!=null)ShoreClient.recorder.disconnected(reason);
    }
}
