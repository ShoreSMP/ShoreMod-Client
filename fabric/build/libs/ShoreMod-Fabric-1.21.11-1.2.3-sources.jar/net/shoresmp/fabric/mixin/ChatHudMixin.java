package net.shoresmp.fabric.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_303;
import net.minecraft.class_310;
import net.minecraft.class_338;
import net.minecraft.text.*;
import net.shoresmp.fabric.ShoreClient;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Mixin(class_338.class)
public abstract class ChatHudMixin {
    @Shadow @Final private List<class_303> messages;
    @Shadow private int scrolledLines;
    // Increase both stored messages and wrapped visible lines so scrolling reaches the retained history.
    @ModifyConstant(method={"addMessage(Lnet/minecraft/client/gui/hud/ChatHudLine;)V","addVisibleMessage"},constant=@Constant(intValue=100))
    private int shore$historyLimit(int vanilla){
        if(ShoreClient.config==null)return 5000;
        return ShoreClient.config.extendedChat?ShoreClient.config.chatHistoryLimit:vanilla;
    }
    @Shadow @Final private List<class_303.class_7590> visibleMessages;
    /** Plain text and repeat count of each line we added, so a repeat can find and merge with it. */
    @Unique private final Map<class_303,String> shore$keys=new WeakHashMap<>();
    @Unique private final Map<class_303,Integer> shore$counts=new WeakHashMap<>();
    @Unique private String shore$pendingKey;
    @Unique private boolean shore$pendingMention;
    /** Chat lines that mention the player, and their wrapped screen lines (filled with the highlight color). */
    @Unique private static final Set<class_303> SHORE_MENTIONS=Collections.newSetFromMap(new WeakHashMap<>());
    @Unique private static final Set<class_303.class_7590> SHORE_MENTION_LINES=Collections.newSetFromMap(new WeakHashMap<>());
    @Unique private static final int[] SHORE_MENTION_COLORS={0xF5C542,-1,0xFF5C5C,0x5CD65C,0x5C9DFF};

    /** Whole-word match of the player's name or a highlight word, ignoring the player's own sender prefix. */
    @Unique private static boolean shore$mentions(String plain){
        var config=ShoreClient.config;var player=class_310.method_1551().field_1724;
        List<String> words=new ArrayList<>();
        if(player!=null)words.add(player.method_5477().getString());
        for(String w:config.highlightWords)if(w!=null&&!w.isBlank())words.add(w.strip());
        String self=player==null?null:player.method_5477().getString();
        for(String w:words){
            var m=java.util.regex.Pattern.compile("(?<![A-Za-z0-9_])"+java.util.regex.Pattern.quote(w)+"(?![A-Za-z0-9_])",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(plain);
            while(m.find()){
                // Your own name as the sender ("<name> hi", "[Rank] name: hi") or as the subject at the start
                // of a server message ("name has made the advancement", "name joined") is not a mention.
                String after=plain.substring(m.end()).stripLeading();
                String before=plain.substring(0,m.start());
                boolean own=w.equalsIgnoreCase(self);
                boolean sender=own&&m.start()<=24&&!after.isEmpty()&&":>]»".indexOf(after.charAt(0))>=0;
                boolean subject=own&&before.replaceAll("\\[[^\\]]*\\]|[^A-Za-z0-9_]","").isEmpty();
                if(!sender&&!subject)return true;
            }
        }
        return false;
    }
    @Inject(method="addVisibleMessage",at=@At("TAIL"))
    private void shore$markMention(class_303 line,CallbackInfo ci){
        if(shore$pendingMention){SHORE_MENTIONS.add(line);shore$pendingMention=false;}
        if(!SHORE_MENTIONS.contains(line)||visibleMessages.isEmpty())return;
        // The newest message's wrapped lines sit at the front, ending with the first endOfEntry line.
        for(int i=0;i<visibleMessages.size();i++){
            SHORE_MENTION_LINES.add(visibleMessages.get(i));
            if(i+1>=visibleMessages.size()||visibleMessages.get(i+1).comp_898())break;
        }
    }
    /** Replaces the dark background behind a mention line with the highlight color. */
    @com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation(method="method_75802",
        at=@At(value="INVOKE",target="Lnet/minecraft/client/gui/hud/ChatHud$Backend;fill(IIIII)V"))
    private static void shore$highlight(class_338.class_12233 backend,int x1,int y1,int x2,int y2,int color,
            com.llamalad7.mixinextras.injector.wrapoperation.Operation<Void> original,
            @com.llamalad7.mixinextras.sugar.Local(argsOnly=true) class_303.class_7590 line,
            @com.llamalad7.mixinextras.sugar.Local(argsOnly=true,ordinal=1) float fade){
        var config=ShoreClient.config;
        if(config==null||!config.mentionHighlight||!SHORE_MENTION_LINES.contains(line)){original.call(backend,x1,y1,x2,y2,color);return;}
        int rgb=config.mentionColor==5?config.mentionCustomColor:config.mentionColor==1?config.accent:SHORE_MENTION_COLORS[config.mentionColor];
        int alpha=Math.round(Math.clamp(fade,0f,1f)*0x70);
        original.call(backend,x1,y1,x2,y2,(alpha<<24)|rgb);
        original.call(backend,x1,y1,x1+2,y2,(Math.round(Math.clamp(fade,0f,1f)*255)<<24)|rgb);
    }
    @Unique private int shore$count=1;

    /**
     * Message stacking: if the same text (ignoring formatting) appeared within the last few messages,
     * that earlier copy is removed and the new one is shown at the bottom with an increased count.
     * Only the old message's own wrapped lines are removed, so the rest of the history is untouched.
     */
    @Inject(method="addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",at=@At("HEAD"),order=900)
    private void shore$duplicates(class_2561 message,net.minecraft.class_7469 signature,net.minecraft.class_7591 indicator,CallbackInfo ci){
        shore$count=1;shore$pendingKey=null;
        var config=ShoreClient.config;
        if(config==null)return;
        String key=message.getString().strip();
        shore$pendingKey=key;
        shore$pendingMention=config.mentionHighlight&&shore$mentions(key);
        if(!config.filterDuplicates||key.isEmpty())return;
        int group=0; // start of the current message's lines in visibleMessages (newest first)
        for(int i=0;i<Math.min(config.stackLookback,messages.size());i++){
            class_303 line=messages.get(i);
            int len=0;
            while(group+len<visibleMessages.size()){len++;if(group+len>=visibleMessages.size()||visibleMessages.get(group+len).comp_898())break;}
            if(key.equals(shore$keys.get(line))&&Objects.equals(indicator,line.comp_894())){
                shore$count=Math.min(999_999,shore$counts.getOrDefault(line,1)+1);
                messages.remove(i);
                for(int k=0;k<len&&group<visibleMessages.size();k++)visibleMessages.remove(group);
                if(scrolledLines>0)scrolledLines=Math.max(0,scrolledLines-len);
                return;
            }
            group+=len;
        }
    }
    @Inject(method="addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",at=@At("TAIL"))
    private void shore$rememberLine(class_2561 message,net.minecraft.class_7469 signature,net.minecraft.class_7591 indicator,CallbackInfo ci){
        if(messages.isEmpty()||shore$pendingKey==null)return;
        class_303 line=messages.getFirst();
        shore$keys.put(line,shore$pendingKey);shore$counts.put(line,shore$count);
    }
    @ModifyVariable(method="addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",at=@At("HEAD"),argsOnly=true,ordinal=0,order=1100)
    private class_2561 shore$decorate(class_2561 message){
        if(ShoreClient.config==null)return message;
        var config=ShoreClient.config;var result=class_2561.method_43473();String plain=message.getString().toLowerCase(Locale.ROOT);
        if(config.timestamps){
            String pattern=(config.timestamps24?"HH:mm":"h:mm")+(config.timestampSeconds?":ss":"")+(config.timestamps24?"":" a");
            result.method_10852(class_2561.method_43470("["+LocalTime.now().format(DateTimeFormatter.ofPattern(pattern,Locale.ROOT))+"] ").method_54663(0x829AAE));
        }
        boolean highlight=shore$pendingMention;
        // shore$count is already updated by shore$duplicates (order 900); only ping for the first copy.
        if(highlight&&config.mentionSound&&shore$count==1)
            class_310.method_1551().method_1483().method_4873(net.minecraft.class_1109.method_47978(net.minecraft.class_3417.field_14622,1.6f));
        // Keep original styles, links and hover events intact.
        result.method_10852(message);
        if(config.filterDuplicates && shore$count>1)
            result.method_10852(class_2561.method_43470(switch(config.stackStyle){case 1->" ("+shore$count+")";case 2->" x"+shore$count;default->" [x"+shore$count+"]";}).method_10862(class_2583.field_24360.method_36139(0xAAAAAA)));
        return result;
    }
}

