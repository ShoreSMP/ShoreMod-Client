package net.shoresmp.fabric;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.*;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.*;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.shoresmp.core.*;
import org.lwjgl.glfw.GLFW;
import org.slf4j.*;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

public final class ShoreClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("ShoreMod");
    public static Config config;
    public static final Roster roster = new Roster();
    public static ClipRecorder recorder;
    public static final PaymentQueue payments = new PaymentQueue();
    public static long lastRosterAt;
    public static long sessionEpoch;
    private static final AtomicReference<Supplier<class_437>> pendingScreen=new AtomicReference<>();
    public static void openNextTick(Supplier<class_437> screen){pendingScreen.set(screen);}
    private static long nextHello;
    private static boolean backendConfirmed;
    public static void resyncPresence(){nextHello=0;}
    public static String presenceStatus(){return lastRosterAt!=0?roster.users().size()+" mod users synced":backendConfirmed?"Server confirmed; waiting for roster":"Waiting for server handshake";}
    private static long nextUpdateCheck;
    public static ModUpdates.Notice latestUpdate;
    private static String announcedUpdate="";
    public static String version(){return net.fabricmc.loader.api.FabricLoader.getInstance().getModContainer("shoremod_universal").or(()->net.fabricmc.loader.api.FabricLoader.getInstance().getModContainer("shoremod")).orElseThrow().getMetadata().getVersion().getFriendlyString();}
    public static boolean updateAvailable(){return latestUpdate!=null&&ModUpdates.newer(latestUpdate.version(),version());}
    public static void checkUpdates(){nextUpdateCheck=0;}
    public static void openUpdate(){if(latestUpdate!=null&&!latestUpdate.url().isEmpty())net.minecraft.class_156.method_668().method_673(java.net.URI.create(latestUpdate.url()));}
    private Double originalChatOpacity;
    public static class_304 menuKey, clipKey;
    /** Localized name of the key currently bound, e.g. "F8", for hints in the UI. */
    public static String keyName(class_304 key){return key==null||key.method_1415()?"Unbound":key.method_16007().getString();}
    private static final class_304.class_11900 CATEGORY = class_304.class_11900.method_74698(class_2960.method_60655("shoremod", "controls"));
    @Override public void onInitializeClient() {
        config = Config.load(); recorder = new ClipRecorder();
        var menu = menuKey = key("menu", GLFW.GLFW_KEY_RIGHT_SHIFT);
        var clip = clipKey = key("clip", GLFW.GLFW_KEY_F9);
        ShoreTools.zoomKey = key("zoom", GLFW.GLFW_KEY_C);
        ShoreHud.register();
        ShoreTools.register();
        ShorePvp.register();
        PayloadTypeRegistry.playC2S().register(UpdatePayload.ID, UpdatePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(UpdatePayload.ID, UpdatePayload.CODEC);
        ClientPlayNetworking.registerGlobalReceiver(UpdatePayload.ID,(payload,context)->{
            try{var notice=ModUpdates.decode(payload.bytes());context.client().execute(()->{
                latestUpdate=notice;
                if(updateAvailable()&&!notice.version().equals(announcedUpdate)){
                    announcedUpdate=notice.version();tell("Update "+notice.version()+" is available. You have "+version()+". Open /shore > Updates.");
                }
            });}catch(IOException e){LOG.warn("Invalid update announcement",e);}
        });
        PayloadTypeRegistry.playC2S().register(ShorePayload.ID, ShorePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ShorePayload.ID, ShorePayload.CODEC);
        ClientPlayNetworking.registerGlobalReceiver(ShorePayload.ID, (payload, context) -> {
            try {
                Wire.Message message = Wire.decode(payload.bytes());
                if (message.op() == Wire.HELLO) { backendConfirmed=true;nextHello=0;sessionEpoch++; roster.clear(); lastRosterAt = 0; payments.cancel(false); }
                else if (message.op() == Wire.ROSTER && roster.accept(message)) lastRosterAt = System.nanoTime();
                else if (message.op() == Wire.CLIP) recorder.trigger(message.reason(), true);
            } catch (IOException e) { LOG.warn("Invalid ShoreMod server payload", e); }
        });
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            sessionEpoch++; latestUpdate=null;announcedUpdate="";nextUpdateCheck=0;
            backendConfirmed=false;roster.clear(); lastRosterAt = 0; nextHello = 0; payments.cancel(false);
            recorder.beginSession();
            ShoreTools.joined(client);
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            sessionEpoch++;
            pendingScreen.set(null);latestUpdate=null;announcedUpdate="";
            backendConfirmed=false;payments.cancel(false); roster.clear(); lastRosterAt = 0;
            // Keep the ring briefly: disconnect screen/transfer reasons may arrive after this event.
        });
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> recorder.trigger(message.getString(), false));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            var screen=pendingScreen.getAndSet(null);
            if(screen!=null)client.method_1507(screen.get());
            while (menu.method_1436()) client.method_1507(new ShoreScreen(client.field_1755));
            while (clip.method_1436()) recorder.trigger("Manually saved gameplay", true);
            long now = System.nanoTime();
            if(client.method_1562()!=null&&now>=nextUpdateCheck&&ClientPlayNetworking.canSend(UpdatePayload.ID)){
                ClientPlayNetworking.send(new UpdatePayload(ModUpdates.request()));nextUpdateCheck=now+60_000_000_000L;
            }
            if (client.method_1562() != null && now >= nextHello && (backendConfirmed||ClientPlayNetworking.canSend(ShorePayload.ID))) {
                ClientPlayNetworking.send(new ShorePayload(Wire.hello())); nextHello = now + 10_000_000_000L;
            }
            if (lastRosterAt != 0 && now - lastRosterAt > 35_000_000_000L) { roster.clear(); lastRosterAt = 0; }
            payments.tick(client);
            ShoreTools.tick(client);
            ShorePvp.tick(client);
            if (config.extendedChat) client.field_1690.method_42550().method_41748(config.chatOpacity);
            else if (originalChatOpacity != null) client.field_1690.method_42550().method_41748(originalChatOpacity);
        });
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> originalChatOpacity = client.field_1690.method_42550().method_41753());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            recorder.close();
            ShoreTools.restoreZoomInput(client);
            if (originalChatOpacity != null) client.field_1690.method_42550().method_41748(originalChatOpacity);
        });
        ShoreCommands.register();
        ShoreSelfTest.register(); // inert unless -Dshoremod.selftest is set
    }
    private class_304 key(String name, int code) {
        return KeyBindingHelper.registerKeyBinding(new class_304("key.shoremod." + name, class_3675.class_307.field_1668, code, CATEGORY));
    }
    public static void tell(String value){message(value,0xEAF2F7);}
    public static void tellError(String value){message(value,0xFF9696);}
    private static void message(String value,int color) {
        class_310 client = class_310.method_1551();
        client.execute(() -> client.field_1705.method_1743().method_1812(class_2561.method_43473().method_10852(class_2561.method_43470("SHOREMOD").method_54663(config.accent).method_27692(net.minecraft.class_124.field_1067)).method_10852(class_2561.method_43470(" \u00BB ").method_54663(0x7F929E)).method_10852(class_2561.method_43470(value).method_54663(color))));
    }
}
