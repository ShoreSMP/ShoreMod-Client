package net.shoresmp.fabric;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.class_11719;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.text.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Compact info panel (FPS, ping, position, biome, clock) plus an equipment durability column. */
public final class ShoreHud {
    private static final DateTimeFormatter CLOCK=DateTimeFormatter.ofPattern("HH:mm");
    private static final class_1304[] SLOTS={class_1304.field_6169,class_1304.field_6174,class_1304.field_6172,class_1304.field_6166,class_1304.field_6173,class_1304.field_6171};
    private static final class_2960 UI=class_2960.method_60655("shoremod","ui");
    private ShoreHud(){}

    public static void register(){
        HudElementRegistry.addLast(class_2960.method_60655("shoremod","hud"),(ctx,tick)->render(ctx));
        HudElementRegistry.replaceElement(net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.CROSSHAIR,vanilla->(ctx,tick)->{
            Config c=ShoreClient.config;var client=class_310.method_1551();
            if(c==null||!c.crosshair||!client.field_1690.method_31044().method_31034()||client.field_1690.field_1842
                ||client.method_53526().method_53536()||client.field_1724==null||client.field_1724.method_7325())vanilla.render(ctx,tick);
            else crosshair(ctx);
        });
    }
    private static class_2561 ui(String s){return class_2561.method_43470(s).method_10862(class_2583.field_24360.method_27704(new class_11719.class_11721(UI)));}

    private record Readout(String id,String text){}
    private static List<Readout> cachedReadouts=List.of();
    private static long nextReadouts,cachedSession;
    private static Object readoutPlayer;
    /** One short readout per box, e.g. "118 FPS" or "XYZ: 3, -60, 10", tagged with its module id for sizing. */
    private static List<Readout> lines(class_310 client){
        long now=System.nanoTime();
        if(now<nextReadouts&&readoutPlayer==client.field_1724&&cachedSession==ShoreClient.sessionEpoch)return cachedReadouts;
        Config c=ShoreClient.config;var player=client.field_1724;var out=new ArrayList<Readout>();
        boolean hidePosition=false;
        if(c.hudFps)out.add(new Readout("fps",client.method_47599()+" FPS"));
        if(c.hudPing&&player!=null&&client.method_1562()!=null&&!client.method_1542()){
            var entry=client.method_1562().method_2871(player.method_5667());
            if(entry!=null)out.add(new Readout("ping",entry.method_2959()+" ms"));
        }
        if(c.hudCoords&&player!=null&&!hidePosition){
            out.add(new Readout("coords","XYZ: "+player.method_31477()+", "+player.method_31478()+", "+player.method_31479()));
            var facing=player.method_5735();
            String axis=switch(facing){case field_11043->"-Z";case field_11035->"+Z";case field_11034->"+X";case field_11039->"-X";default->"";};
            out.add(new Readout("coords",title(facing.method_15434())+" ("+axis+")"));
        }
        if(c.hudBiome&&player!=null&&client.field_1687!=null&&!hidePosition)
            out.add(new Readout("biome",client.field_1687.method_23753(player.method_24515()).method_40230().map(k->title(k.method_29177().method_12832())).orElse("Unknown")));
        if(c.hudClock)out.add(new Readout("clock",LocalTime.now().format(CLOCK)));
        var target=ShorePvp.target();
        if(c.targetHud&&target!=null)out.add(new Readout("target",target.method_5477().getString()+"  ❤ "+String.format(Locale.ROOT,"%.1f",target.method_6032()+target.method_6067())+(c.targetDistance?String.format(Locale.ROOT,"  %.1fm",target.method_5739(player)):"")));
        if(c.potionHud&&player!=null){
            var effects=new ArrayList<>(player.method_6026());
            effects.sort(Comparator.comparingInt(e->-e.method_5584()));
            for(var e:effects){
                String name=e.method_5579().comp_349().method_5560().getString();
                int lvl=e.method_5578()+1;
                String roman=lvl<=1?"":" "+(lvl<=10?new String[]{"","I","II","III","IV","V","VI","VII","VIII","IX","X"}[lvl]:String.valueOf(lvl));
                int secs=e.method_5584()/20;
                String time=e.method_48559()?"∞":String.format(Locale.ROOT,"%d:%02d",secs/60,secs%60);
                out.add(new Readout("potions",name+roman+"  "+time));
            }
        }
        if(c.cps)out.add(new Readout("cps",c.cpsRight?ShoreTools.cps(true)+" | "+ShoreTools.cps(false)+" CPS":ShoreTools.cps(true)+" CPS"));
        if(player!=null&&c.toggleSprintHud){
            if(c.toggleSneak&&client.field_1690.field_1832.method_1434())out.add(new Readout("togglesprint","Sneaking (Toggled)"));
            else if(c.toggleSprint&&client.field_1690.field_1867.method_1434())out.add(new Readout("togglesprint","Sprinting (Toggled)"));
        }
        nextReadouts=now+100_000_000L;readoutPlayer=client.field_1724;cachedSession=ShoreClient.sessionEpoch;cachedReadouts=List.copyOf(out);
        return cachedReadouts;
    }

    static String title(String id){
        var sb=new StringBuilder();
        for(String part:id.split("_")){if(part.isEmpty())continue;if(!sb.isEmpty())sb.append(' ');sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));}
        return sb.toString();
    }

    private static final int TEXT=0xFFFFFFFF;
    private static int box(){return (Math.round(ShoreClient.config.hudBgOpacity*2.55f)<<24)|0x101217;}
    private static int textColor(){Config c=ShoreClient.config;return switch(c.hudTextColor){case 1->0xFF000000|c.accent;case 2->0xFFC8CDD3;case 3->0xFF000000|c.hudCustomColor;default->TEXT;};}
    /**
     * Classic PvP-client HUD: each readout in its own small dark box, Minecraft's own pixel font with
     * its drop shadow, drawn in GUI units so it matches vanilla text exactly.
     */
    /** One stacked HUD element: unscaled size, its scale, and how to draw it at (0,0). */
    private record Block(int w,int h,float scale,java.util.function.Consumer<class_332> draw){}
    private static final int BOX_H=16,GEAR_H=20,PAD_X=5,KEY=20,KEY_GAP=2;

    private static void render(class_332 ctx){
        var client=class_310.method_1551();Config c=ShoreClient.config;
        if(c==null||client.field_1724==null||client.field_1690.field_1842||client.method_53526().method_53536())return;
        var tr=client.field_1772;
        float global=net.shoresmp.core.HudScale.guiUnits(client.method_22683().method_4506(),client.method_22683().method_4495(),c.hudScale,100);
        List<Block> blocks=new ArrayList<>();
        for(Readout r:lines(client)){
            int w=tr.method_1727(r.text())+PAD_X*2;
            blocks.add(new Block(w,BOX_H,global*c.hudSize(r.id())/100f,g->{
                box(g,0,0,w,BOX_H);
                g.method_51433(tr,r.text(),PAD_X,(BOX_H-8)/2+1,textColor(),c.hudShadow);
            }));
        }
        if(c.keystrokes)blocks.add(keystrokes(client,global*c.hudSize("keystrokes")/100f));
        if(c.itemCounter){
            float sc=global*c.hudSize("items")/100f;
            for(var count:itemCounts(client,c))if(count.amount()>0||c.itemsShowZero)blocks.add(itemRow(tr,count.icon(),count.label(),textColor(),sc));
        }
        if(c.hudArmor){
            float sc=global*c.hudSize("armor")/100f;
            for(class_1304 slot:SLOTS){
                class_1799 s=client.field_1724.method_6118(slot);
                if(s.method_7960()||!s.method_7963())continue;
                int max=s.method_7936(),left=max-s.method_7919(),pct=max<=0?100:Math.round(left*100f/max);
                int color=pct>50?textColor():pct>Math.max(c.durabilityThreshold,20)?0xFFFFFF55:0xFFFF5555;
                blocks.add(itemRow(tr,s,pct+"%",color,sc));
            }
        }
        if(blocks.isEmpty())return;

        // Stack the blocks down from the chosen corner, each at its own scale. When a column would run
        // into chat (left side) or off the screen, the next blocks start a new column beside it.
        int sw=ctx.method_51421(),sh=ctx.method_51443();
        boolean right=c.hudCorner==1||c.hudCorner==3,bottom=c.hudCorner>=2;
        final float gap=2*global,margin=4*global;
        float topOffset=right&&!bottom&&!client.field_1724.method_6026().isEmpty()?52:0;
        int chatH=net.minecraft.class_338.method_1818(client.field_1690.method_41801().method_41753())+48;
        float avail=Math.max(60,sh-margin*2-topOffset-(right?0:Math.min(sh*0.6f,chatH)));
        List<List<Block>> columns=new ArrayList<>();List<Block> col=new ArrayList<>();float colH=0;
        for(Block b:blocks){
            float h=b.h()*b.scale();
            if(!col.isEmpty()&&colH+gap+h>avail){columns.add(col);col=new ArrayList<>();colH=0;}
            colH+=(col.isEmpty()?0:gap)+h;col.add(b);
        }
        columns.add(col);
        var m=ctx.method_51448();
        float colX=margin;
        for(List<Block> column:columns){
            float height=-gap,width=0;
            for(Block b:column){height+=b.h()*b.scale()+gap;width=Math.max(width,b.w()*b.scale());}
            float y=bottom?sh-margin-height-(right?0:60):margin+topOffset;
            for(Block b:column){
                float x=right?sw-colX-b.w()*b.scale():colX;
                m.pushMatrix();m.translate(x,y);m.scale(b.scale(),b.scale());
                b.draw().accept(ctx);
                m.popMatrix();
                y+=b.h()*b.scale()+gap;
            }
            colX+=width+gap*2;
        }
    }
    private static Block itemRow(net.minecraft.class_327 tr,class_1799 stack,String label,int color,float sc){
        int w=PAD_X+16+4+tr.method_1727(label)+PAD_X;
        return new Block(w,GEAR_H,sc,g->{
            box(g,0,0,w,GEAR_H);
            g.method_51427(stack,PAD_X-1,2);
            g.method_51433(tr,label,PAD_X+19,(GEAR_H-8)/2+1,color,ShoreClient.config.hudShadow);
        });
    }
    private record ItemCount(class_1799 icon,int amount,String label){}
    private static List<ItemCount> cachedItems=List.of();
    private static long nextItems,itemSession;
    private static Object itemPlayer;
    private static List<ItemCount> itemCounts(class_310 client,Config config){
        long now=System.nanoTime();if(now<nextItems&&itemPlayer==client.field_1724&&itemSession==ShoreClient.sessionEpoch)return cachedItems;
        var result=new ArrayList<ItemCount>();var inventory=client.field_1724.method_31548();
        for(var group:counted(config)){
            int count=0;for(int i=0;i<inventory.method_5439();i++)for(var item:group)if(inventory.method_5438(i).method_31574(item))count+=inventory.method_5438(i).method_7947();
            result.add(new ItemCount(new class_1799(group[0]),count,String.valueOf(count)));
        }
        nextItems=now+100_000_000L;itemPlayer=client.field_1724;itemSession=ShoreClient.sessionEpoch;return cachedItems=List.copyOf(result);
    }
    /** Items the counter shows; each group is counted together (e.g. both kinds of golden apple). */
    private static List<net.minecraft.class_1792[]> counted(Config c){
        var out=new ArrayList<net.minecraft.class_1792[]>();
        if(c.itemsTotem)out.add(new net.minecraft.class_1792[]{net.minecraft.class_1802.field_8288});
        if(c.itemsPearl)out.add(new net.minecraft.class_1792[]{net.minecraft.class_1802.field_8634});
        if(c.itemsGapple)out.add(new net.minecraft.class_1792[]{net.minecraft.class_1802.field_8463,net.minecraft.class_1802.field_8367});
        if(c.itemsCrystal)out.add(new net.minecraft.class_1792[]{net.minecraft.class_1802.field_8301});
        if(c.itemsArrow)out.add(new net.minecraft.class_1792[]{net.minecraft.class_1802.field_8107,net.minecraft.class_1802.field_8236,net.minecraft.class_1802.field_8087});
        if(c.itemsXp)out.add(new net.minecraft.class_1792[]{net.minecraft.class_1802.field_8287});
        // Your own items, by id: "cobweb" or "minecraft:obsidian".
        for(String raw:c.itemsCustom){
            var id=class_2960.method_12829(raw.strip().toLowerCase(Locale.ROOT));
            if(id==null)continue;
            var item=net.minecraft.class_7923.field_41178.method_63535(id);
            if(item!=net.minecraft.class_1802.field_8162)out.add(new net.minecraft.class_1792[]{item});
        }
        return out;
    }
    /** WASD, mouse buttons (with clicks per second) and the space bar, lit while held. */
    private static Block keystrokes(class_310 client,float sc){
        Config c=ShoreClient.config;var o=client.field_1690;var tr=client.field_1772;
        int w=KEY*3+KEY_GAP*2,h=KEY*2+KEY_GAP+(c.keystrokesMouse?KEY_GAP+KEY:0)+(c.keystrokesSpace?KEY_GAP+12:0);
        return new Block(w,h,sc,g->{
            key(g,tr,KEY+KEY_GAP,0,KEY,KEY,ShoreClient.keyName(o.field_1894),o.field_1894.method_1434());
            int y=KEY+KEY_GAP;
            key(g,tr,0,y,KEY,KEY,ShoreClient.keyName(o.field_1913),o.field_1913.method_1434());
            key(g,tr,KEY+KEY_GAP,y,KEY,KEY,ShoreClient.keyName(o.field_1881),o.field_1881.method_1434());
            key(g,tr,(KEY+KEY_GAP)*2,y,KEY,KEY,ShoreClient.keyName(o.field_1849),o.field_1849.method_1434());
            y+=KEY+KEY_GAP;
            if(c.keystrokesMouse){
                int half=(w-KEY_GAP)/2;
                key(g,tr,0,y,half,KEY,ShoreTools.cps(true)+" CPS",o.field_1886.method_1434());
                key(g,tr,half+KEY_GAP,y,w-half-KEY_GAP,KEY,ShoreTools.cps(false)+" CPS",o.field_1904.method_1434());
                y+=KEY+KEY_GAP;
            }
            if(c.keystrokesSpace){
                boolean down=o.field_1903.method_1434();
                if(down)notched(g,0,y,w,12,pressedColor());else box(g,0,y,w,12);
                g.method_25294(w/2-12,y+5,w/2+12,y+7,down?0xFF101010:textColor());
            }
        });
    }
    private static void key(class_332 g,net.minecraft.class_327 tr,int x,int y,int w,int h,String label,boolean down){
        if(down)notched(g,x,y,w,h,pressedColor());else box(g,x,y,w,h);
        if(label.length()>4&&w<=KEY)label=label.substring(0,1);
        int tw=tr.method_1727(label);
        g.method_51433(tr,label,x+(w-tw)/2,y+(h-8)/2+1,down?0xFF101010:textColor(),!down&&ShoreClient.config.hudShadow);
    }
    private static int pressedColor(){Config c=ShoreClient.config;return c.keystrokesAccent?0xD0000000|c.accent:0xD0FFFFFF;}
    private static void notched(class_332 g,int x,int y,int w,int h,int color){
        g.method_25294(x+1,y,x+w-1,y+h,color);g.method_25294(x,y+1,x+1,y+h-1,color);g.method_25294(x+w-1,y+1,x+w,y+h-1,color);
    }
    static final int[] CROSSHAIR_COLORS={0xFFFFFFFF,-1,0xFF55FF55,0xFFFF5555,0xFF55FFFF,0xFFFFFF55};
    static final String[] CROSSHAIR_NAMES={"White","Accent","Green","Red","Cyan","Yellow","Custom"};
    /** Plus-shaped crosshair with configurable arm length, gap, thickness, color, dot and outline. */
    private static void crosshair(class_332 ctx){
        Config c=ShoreClient.config;
        int alpha=Math.round(c.crosshairOpacity*2.55f);
        int base=c.crosshairColor==6?0xFF000000|c.crosshairCustomColor:c.crosshairColor==1?0xFF000000|c.accent:CROSSHAIR_COLORS[c.crosshairColor];
        int color=(alpha<<24)|(base&0xFFFFFF);
        int cx=ctx.method_51421()/2,cy=ctx.method_51443()/2;
        if(c.crosshairMode==1){
            class_2960 tex=CrosshairImage.texture(c.crosshairImage);
            if(tex!=null){
                int s=c.crosshairImageSize,tint=c.crosshairTint?color:(alpha<<24)|0xFFFFFF;
                ctx.method_25291(net.minecraft.class_10799.field_56883,tex,cx-s/2,cy-s/2,0f,0f,s,s,s,s,tint);
                return;
            }
        }
        int t=c.crosshairThickness,len=c.crosshairLength,gap=c.crosshairGap,h=t/2;
        int[][] arms={{cx-h,cy-gap-len,t,len},{cx-h,cy+gap+(t%2==0?0:1),t,len},{cx-gap-len,cy-h,len,t},{cx+gap+(t%2==0?0:1),cy-h,len,t}};
        if(c.crosshairOutline){
            int outline=(Math.round(alpha*0.75f)<<24);
            for(int[] a:arms)ctx.method_25294(a[0]-1,a[1]-1,a[0]+a[2]+1,a[1]+a[3]+1,outline);
            if(c.crosshairDot)ctx.method_25294(cx-h-1,cy-h-1,cx-h+t+1,cy-h+t+1,outline);
        }
        for(int[] a:arms)ctx.method_25294(a[0],a[1],a[0]+a[2],a[1]+a[3],color);
        if(c.crosshairDot)ctx.method_25294(cx-h,cy-h,cx-h+t,cy-h+t,color);
    }

    /** A crosshair picture chosen by the player, loaded from disk and reloaded when the file changes. */
    static final class CrosshairImage {
        private static final class_2960 ID=class_2960.method_60655("shoremod","dyn/crosshair_image");
        private static String loadedPath="";
        private static long loadedStamp;
        private static boolean ok;
        private static long nextCheck;
        static void invalidate(){loadedPath="";loadedStamp=0;nextCheck=0;ok=false;}
        static class_2960 texture(String path){
            if(path==null||path.isBlank())return null;
            long now=System.nanoTime();
            if(path.equals(loadedPath)&&now<nextCheck)return ok?ID:null;
            nextCheck=now+1_000_000_000L;
            var file=java.nio.file.Path.of(path);
            long stamp;
            try{stamp=java.nio.file.Files.getLastModifiedTime(file).toMillis();}catch(Exception e){loadedPath=path;loadedStamp=0;ok=false;return null;}
            if(!path.equals(loadedPath)||stamp!=loadedStamp){
                loadedPath=path;loadedStamp=stamp;ok=false;
                try(var in=java.nio.file.Files.newInputStream(file)){
                    if(java.nio.file.Files.size(file)>4*1024*1024)throw new java.io.IOException("Image exceeds 4 MiB");
                    try(var header=javax.imageio.ImageIO.createImageInputStream(file.toFile())){
                        var readers=javax.imageio.ImageIO.getImageReaders(header);
                        if(!readers.hasNext())throw new java.io.IOException("Unsupported image");
                        var reader=readers.next();
                        try{reader.setInput(header);if(reader.getWidth(0)>512||reader.getHeight(0)>512)throw new java.io.IOException("Image must be at most 512x512");}finally{reader.dispose();}
                    }
                    var img=net.minecraft.class_1011.method_4309(in);
                    if(img.method_4307()>512||img.method_4323()>512){img.close();ShoreClient.tellError("Crosshair image must be 512x512 or smaller.");return null;}
                    class_310.method_1551().method_1531().method_4616(ID,new net.minecraft.class_1043(()->"shoremod crosshair",img));
                    ok=true;
                }catch(Exception e){ShoreClient.tellError("Could not load crosshair image: "+e.getMessage());}
            }
            return ok?ID:null;
        }
        /** Copies a chosen picture into config/shoremod/crosshairs so it keeps working if the original moves. */
        static String importFile(java.nio.file.Path source) throws java.io.IOException{
            var image=net.shoresmp.core.CrosshairImages.read(source);
            var dir=folder();java.nio.file.Files.createDirectories(dir);
            var target=java.nio.file.Files.createTempFile(dir,"crosshair-",".png");
            try{if(!javax.imageio.ImageIO.write(image,"png",target.toFile()))throw new java.io.IOException("PNG encoder unavailable");}
            catch(java.io.IOException e){java.nio.file.Files.deleteIfExists(target);throw e;}finally{image.flush();}
            return target.toAbsolutePath().toString();
        }
        static java.nio.file.Path folder(){return net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("shoremod/crosshairs");}
    }
    /** Dark box with one-pixel corner notches, like vanilla's own UI rounding. */
    private static void box(class_332 ctx,int x,int y,int w,int h){
        ctx.method_25294(x+1,y,x+w-1,y+h,box());
        ctx.method_25294(x,y+1,x+1,y+h-1,box());
        ctx.method_25294(x+w-1,y+1,x+w,y+h-1,box());
    }
}

