package net.shoresmp.fabric;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2595;
import net.minecraft.class_310;
import net.minecraft.class_318;
import net.minecraft.class_465;
import net.minecraft.class_476;
import org.lwjgl.glfw.GLFW;
import java.nio.file.Files;
import java.util.*;
import java.util.function.*;

/**
 * Developer-only self test, inert unless the JVM is started with -Dshoremod.selftest=ui|world
 * (see the selfTestUi / selfTestWorld Loom run configs). It screenshots every settings tab, and in
 * a throwaway world drives the inventory tweaks with real slot clicks and checks the results.
 */
final class ShoreSelfTest {
    private ShoreSelfTest(){}
    private record Step(int delay,Predicate<class_310> ready,Consumer<class_310> action){}
    private static final Deque<Step> steps=new ArrayDeque<>();
    private static final List<String> report=new ArrayList<>();
    private static int countdown=-1;

    static void register(){
        String mode=System.getProperty("shoremod.selftest","");
        if(mode.isEmpty())return;
        ShoreClient.LOG.warn("ShoreMod self test enabled: {}",mode);
        if(mode.equals("ui"))planUi();else if(mode.equals("world"))planWorld();else if(mode.equals("creative"))planCreative();else if(mode.equals("hud"))planHud();
        ClientTickEvents.END_CLIENT_TICK.register(ShoreSelfTest::tick);
    }
    private static void step(int delay,Consumer<class_310> action){steps.add(new Step(delay,c->true,action));}
    private static void await(Predicate<class_310> ready,int delay){steps.add(new Step(delay,ready,c->{}));}
    private static void tick(class_310 client){
        Step s=steps.peek();if(s==null)return;
        if(countdown<0)countdown=s.delay();
        if(countdown>0){countdown--;return;}
        if(!s.ready().test(client))return;
        steps.poll();countdown=-1;
        try{s.action().accept(client);}catch(Throwable t){log("ERROR in step: "+t);ShoreClient.LOG.error("Self test step failed",t);}
    }
    private static void log(String line){report.add(line);ShoreClient.LOG.warn("[selftest] {}",line);}
    private static void shot(class_310 c,String name){
        class_318.method_22690(c.field_1697,"selftest_"+name+".png",c.method_1522(),1,t->{});
    }
    private static void finish(class_310 c){
        try{Files.write(c.field_1697.toPath().resolve("shoremod-selftest.txt"),report);}catch(Exception e){ShoreClient.LOG.error("report",e);}
        c.method_1592();
    }
    private static void scale(class_310 c,int s){c.field_1690.method_42474().method_41748(s);c.method_15993();}

    // ------------------------------------------------------------------ settings screenshots
    private static void planUi(){
        enterWorld();
        step(40,c->{});
        for(int s:new int[]{2,3}){
            step(2,c->scale(c,s));
            step(4,c->{if(!(c.field_1755 instanceof ShoreScreen))c.method_1507(new ShoreScreen(null));((ShoreScreen)c.field_1755).showGrid("All","");});
            step(12,c->shot(c,"gui"+s+"_grid"));
            step(2,c->{var sc=(ShoreScreen)c.field_1755;sc.method_25401(sc.field_22789*0.5,sc.field_22790*0.7,0,-30);});
            step(20,c->shot(c,"gui"+s+"_grid_scrolled"));
            step(2,c->((ShoreScreen)c.field_1755).showGrid("HUD",""));
            step(10,c->shot(c,"gui"+s+"_hud"));
            step(2,c->((ShoreScreen)c.field_1755).showGrid("All","zzz"));
            step(10,c->shot(c,"gui"+s+"_empty"));
            for(String id:new String[]{"zoom","crosshair","shulker","items","fps"}){
                step(2,c->((ShoreScreen)c.field_1755).showModule(id));
                step(10,c->shot(c,"gui"+s+"_module_"+id));
            }
            step(2,c->{ShoreClient.config.crosshairMode=1;((ShoreScreen)c.field_1755).showModule("crosshair");});
            step(10,c->shot(c,"gui"+s+"_module_crosshair_image"));
            step(2,c->{ShoreClient.config.crosshairMode=0;var sc=(ShoreScreen)c.field_1755;sc.showModule("crosshair");sc.method_25401(sc.field_22789*0.5,sc.field_22790*0.7,0,-30);});
            step(20,c->shot(c,"gui"+s+"_module_crosshair_scrolled"));
            for(String p:new String[]{"GENERAL","CONTROLS","UPDATES"}){
                step(2,c->((ShoreScreen)c.field_1755).showPage(p));
                step(10,c->shot(c,"gui"+s+"_page_"+p.toLowerCase()));
            }
            step(2,c->((ShoreScreen)c.field_1755).showGrid("All",""));
        }
        step(2,c->c.method_1507(new ClipSavedScreen(null,c.field_1697.toPath().resolve("clips/x.avi"),28.4)));
        step(10,c->shot(c,"dialog_clip"));
        step(2,c->c.method_1507(null));
        step(20,c->shot(c,"hud_ui"));
        step(4,c->{log("UI screenshots done");finish(c);});
    }

    // ------------------------------------------------------------------ in-world inventory tests
    private static int sx,sy;
    private static double zoomSens,zoomSensWhile,zoomScaleWhile;
    private static void planWorld(){
        enterWorld();
        planInventory();
    }
    private static int deleteSlot;
    private static class_1735 trashSlot;
    private static void planCreative(){
        enterWorld();
        step(1,c->c.method_1562().method_45730("gamemode creative"));
        await(c->c.field_1724.method_31549().field_7477,20);
        step(2,c->c.method_1507(new net.minecraft.class_481(c.field_1724,c.field_1687.method_45162(),true)));
        step(10,c->{
            try{
                var tab=net.minecraft.class_7706.method_47341().stream().filter(g->g.method_47312()==net.minecraft.class_1761.class_7916.field_41053).findFirst().orElseThrow();
                var method=c.field_1755.getClass().getDeclaredMethod("setSelectedTab",net.minecraft.class_1761.class);method.setAccessible(true);method.invoke(c.field_1755,tab);
                var field=c.field_1755.getClass().getDeclaredField("deleteItemSlot");field.setAccessible(true);trashSlot=(class_1735)field.get(c.field_1755);deleteSlot=trashSlot.field_7874;
                sx=field(c.field_1755,"x");sy=field(c.field_1755,"y");
                ShoreClient.config.mouseTweaks=true;
                ((class_465<?>)c.field_1755).method_17577().method_34254(new class_1799(class_1802.field_20391,16));
                moveToTrash(c);button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,0,true);
            }catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
        });
        step(2,c->button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,0,false));
        step(3,c->{log(verdict(cursor(c).method_7960())+" creative delete X clears held items with mouse tweaks enabled");c.method_1562().method_45730("give @s dirt 32");});
        await(c->c.field_1724.method_31548().method_5438(0).method_31574(class_1802.field_8831),10);
        step(10,c->{
            try{
                // Shift-delete maps to QUICK_MOVE. Exercise that real screen action directly;
                // the preceding ordinary delete uses Minecraft's GLFW mouse callback path.
                var method=c.field_1755.getClass().getDeclaredMethod("onMouseClick",class_1735.class,int.class,int.class,class_1713.class);
                method.setAccessible(true);method.invoke(c.field_1755,trashSlot,deleteSlot,0,class_1713.field_7794);
            }catch(ReflectiveOperationException e){throw new IllegalStateException(e);}});
        step(3,c->{log(verdict(c.field_1724.method_31548().method_5438(0).method_7960())+" creative shift-delete clears inventory");shot(c,"creative_delete");});
        step(2,c->{log("Creative regression tests done");finish(c);});
    }
    private static void moveToTrash(class_310 c){
        var window=c.method_22683();double gx=sx+trashSlot.field_7873+8,gy=sy+trashSlot.field_7872+8;
        invoke(c,"onCursorPos",new Class<?>[]{long.class,double.class,double.class},window.method_4490(),gx*window.method_4480()/window.method_4486(),gy*window.method_4507()/window.method_4502());
    }
    private static volatile int[] measuredHud;
    private static int[] hudGuiOne,hudGuiThree;
    private static float paymentUnit;
    private static void measureHud(class_310 c,String name){
        measuredHud=null;
        class_318.method_1663(c.method_1522(),image->{
            try(image){
                int[] best=null;int bestCount=-1;
                for(int base:new int[]{0,Math.max(0,image.method_4323()-120)}){
                    int minX=image.method_4307(),minY=image.method_4323(),maxX=-1,maxY=-1,count=0;
                    for(int py=base;py<Math.min(image.method_4323(),base+120);py++)for(int px=0;px<Math.min(220,image.method_4307());px++){
                        if((image.method_61940(px,py)&0xFFFFFF)==0x101217){count++;minX=Math.min(minX,px);maxX=Math.max(maxX,px);minY=Math.min(minY,py);maxY=Math.max(maxY,py);}
                    }
                    if(count>bestCount){bestCount=count;best=new int[]{minX,minY,maxX-minX+1,maxY-minY+1};}
                }
                measuredHud=best;
                log("HUD pixels "+name+": "+Arrays.toString(measuredHud));
            }
        });
    }
    private static float paymentUiUnit(class_310 c){
        try{var f=ShoreDialog.class.getDeclaredField("ui");f.setAccessible(true);return ((ShoreUi)f.get(c.field_1755)).u;}catch(Exception e){throw new IllegalStateException(e);}
    }
    private static void paymentButtons(class_310 c){
        try{
            var f=ShoreDialog.class.getDeclaredField("hits");f.setAccessible(true);var hits=(java.util.List<?>)f.get(c.field_1755);
            var ranges=new java.util.ArrayList<float[]>();
            for(Object hit:hits){var x=hit.getClass().getDeclaredMethod("x");var w=hit.getClass().getDeclaredMethod("w");x.setAccessible(true);w.setAccessible(true);ranges.add(new float[]{(float)x.invoke(hit),(float)w.invoke(hit)});}
            ranges.sort(java.util.Comparator.comparingDouble(v->v[0]));boolean fits=ranges.size()==4;
            for(int i=1;i<ranges.size();i++)fits&=ranges.get(i-1)[0]+ranges.get(i-1)[1]<=ranges.get(i)[0];
            if(!ranges.isEmpty())fits&=ranges.getLast()[0]+ranges.getLast()[1]-ranges.getFirst()[0]<=420-48;
            log(verdict(fits)+" payment paging and confirmation buttons fit without overlap");
        }catch(Exception e){throw new IllegalStateException(e);}
    }
    private static void sizeEditing(class_310 c){
        try{
            var screen=(ShoreScreen)c.field_1755;
            var uiField=ShoreScreen.class.getDeclaredField("ui");uiField.setAccessible(true);
            var ui=(ShoreUi)uiField.get(screen);
            var row=screen.slider("Size regression","",50,150,1,"%",()->ShoreClient.config.menuScale,v->ShoreClient.config.menuScale=v);
            row.trackX=100;row.trackW=100;
            var active=ShoreScreen.class.getDeclaredField("activeSlider");active.setAccessible(true);active.set(screen,row);
            var drag=new class_11909(125*ui.u/ui.gs,0,new class_11910(0,0));
            screen.method_25403(drag,0,0);
            log(verdict(ShoreClient.config.menuScale==100)+" size drag keeps layout stable until release");
            screen.method_25406(drag);
            log(verdict(ShoreClient.config.menuScale==75)+" size drag applies final value on release");
            var focus=ShoreScreen.class.getDeclaredField("focused");focus.setAccessible(true);focus.set(screen,row.input);
            row.input.set("100",true);
            log(verdict(ShoreClient.config.menuScale==75)+" typed size stays draft until confirmed");
            var commit=ShoreScreen.class.getDeclaredMethod("finishInput",boolean.class);commit.setAccessible(true);commit.invoke(screen,true);
            log(verdict(ShoreClient.config.menuScale==100)+" confirmed typed size applies");
            focus.set(screen,row.input);row.input.set("5",true);commit.invoke(screen,true);
            log(verdict(ShoreClient.config.menuScale==100&&row.input.text.equals("100"))+" invalid size restores saved value");
            focus.set(screen,row.input);row.input.set("80",true);commit.invoke(screen,false);
            log(verdict(ShoreClient.config.menuScale==100&&row.input.text.equals("100"))+" canceled size preserves saved value");
        }catch(Exception e){throw new IllegalStateException(e);}
    }
    private static void planHud(){
        enterWorld();
        step(2,c->{
            var cfg=ShoreClient.config;cfg.hudClock=true;cfg.hudFps=cfg.hudPing=cfg.hudCoords=cfg.hudBiome=cfg.hudArmor=false;
            cfg.keystrokes=cfg.itemCounter=cfg.potionHud=cfg.targetHud=cfg.cps=cfg.toggleSprintHud=false;
            cfg.hudCorner=0;cfg.hudBgOpacity=100;cfg.hudScale=100;cfg.hudSizes.put("clock",100);scale(c,1);
        });
        step(15,c->measureHud(c,"GUI1 scale100"));await(c->measuredHud!=null,0);
        step(0,c->{hudGuiOne=measuredHud.clone();scale(c,3);});
        step(15,c->measureHud(c,"GUI3 scale100"));await(c->measuredHud!=null,0);
        step(0,c->{hudGuiThree=measuredHud.clone();log(verdict(hudGuiOne[2]>0&&Math.abs(hudGuiOne[2]-hudGuiThree[2])<=1&&Math.abs(hudGuiOne[3]-hudGuiThree[3])<=1)+" HUD physical boxes ignore Minecraft GUI zoom");ShoreClient.config.hudScale=50;});
        step(15,c->measureHud(c,"GUI3 scale50"));await(c->measuredHud!=null,0);
        step(0,c->{log(verdict(measuredHud[2]>0&&Math.abs(measuredHud[2]*2-hudGuiThree[2])<=2&&Math.abs(measuredHud[3]*2-hudGuiThree[3])<=2)+" HUD boxes halve at fifty percent");ShoreClient.config.hudScale=100;ShoreClient.config.hudSizes.put("clock",50);});
        step(15,c->measureHud(c,"GUI3 element50"));await(c->measuredHud!=null,0);
        step(0,c->{log(verdict(Math.abs(measuredHud[2]*2-hudGuiThree[2])<=2&&Math.abs(measuredHud[3]*2-hudGuiThree[3])<=2)+" HUD element setting halves its complete box");
            var users=new java.util.ArrayList<net.shoresmp.core.Wire.User>();for(int i=0;i<8;i++)users.add(new net.shoresmp.core.Wire.User(java.util.UUID.randomUUID(),"Player"+i));
            ShoreClient.config.paymentScale=100;c.method_1507(new PaymentScreen(null,net.shoresmp.core.Payments.each(users,net.shoresmp.core.Payments.amount("5b")),c.method_1562()));});
        step(10,c->{paymentUnit=paymentUiUnit(c);paymentButtons(c);ShoreClient.config.paymentScale=70;});
        step(10,c->{log(verdict(Math.abs(paymentUiUnit(c)/paymentUnit-0.7f)<0.01f)+" payment dialog geometry shrinks to seventy percent");paymentButtons(c);shot(c,"payment_compact");});
        step(2,c->{ShoreClient.config.menuScale=100;c.method_1507(new ShoreScreen(null));((ShoreScreen)c.field_1755).showPage("GENERAL");});
        step(10,ShoreSelfTest::sizeEditing);
        step(2,c->{log("HUD scale regression done");finish(c);});
    }
    private static void enterWorld(){
        // Wait for resource loading to finish before driving the settings UI.
        await(c->c.method_18506()==null&&c.field_1755!=null,200);
        step(0,c->{
            c.field_1690.field_1837=false; // the test window is usually in the background
            String name="ShoreSelfTest-"+System.currentTimeMillis();
            var info=new net.minecraft.class_1940(name,net.minecraft.class_1934.field_9215,false,net.minecraft.class_1267.field_5801,true,
                new net.minecraft.class_1928(net.minecraft.class_7701.field_40183),net.minecraft.class_7712.field_40260);
            c.method_41735().method_41895(name,info,net.minecraft.class_5285.method_64223(),
                net.minecraft.class_5317::method_64225,null);
        });
        await(c->c.field_1724!=null&&c.field_1687!=null&&c.method_1576()!=null&&c.field_1755==null,100);
    }
    private static void planInventory(){
        step(0,c->{
            var cfg=ShoreClient.config;cfg.hudCoords=true;cfg.hudBiome=true;cfg.hudClock=true;
            cfg.mouseTweaks=true;cfg.tweakRmb=true;cfg.tweakLmb=true;cfg.tweakShift=true;cfg.tweakWheel=true;
            var server=c.method_1576();var id=c.field_1724.method_5667();
            server.execute(()->{
                var sp=server.method_3760().method_14602(id);var inv=sp.method_31548();inv.method_5448();
                inv.method_5447(9,new class_1799(class_1802.field_8831,64));          // slot 27
                inv.method_5447(10,new class_1799(class_1802.field_20412,64));  // slot 28
                inv.method_5447(11,new class_1799(class_1802.field_20412,64));  // slot 29
                inv.method_5447(12,new class_1799(class_1802.field_20412,32));  // slot 30
                inv.method_5447(13,new class_1799(class_1802.field_8583,10));      // slot 31
                inv.method_5447(14,new class_1799(class_1802.field_8583,10));      // slot 32
                inv.method_5447(15,new class_1799(class_1802.field_8583,10));      // slot 33
                inv.method_5447(18,new class_1799(class_1802.field_8858,64));         // slot 36
                inv.method_5447(19,new class_1799(class_1802.field_8858,64));         // slot 37
                inv.method_5447(20,new class_1799(class_1802.field_8858,16));         // slot 38
                inv.method_5447(21,new class_1799(class_1802.field_8110,10));       // slot 39
                inv.method_5447(22,new class_1799(class_1802.field_8110,10));       // slot 40
                inv.method_5447(23,new class_1799(class_1802.field_8110,10));       // slot 41
                inv.method_5447(0,new class_1799(class_1802.field_8377));
                var pos=sp.method_24515().method_10078();var world=sp.method_51469();
                world.method_8501(pos,class_2246.field_10034.method_9564());
                if(world.method_8321(pos) instanceof class_2595 chest)sp.method_17355(chest);
            });
        });
        await(c->c.field_1755 instanceof class_476,10);
        step(10,c->{
            var screen=(class_465<?>)c.field_1755;
            sx=field(screen,"x");sy=field(screen,"y");
            log("Chest open. All input below goes through Minecraft's real GLFW mouse callbacks.");
            pickup(c,27);
        });
        step(2,c->{});
        // ---- right-click sweep across chest slots 3, 4, 5
        step(4,c->{moveTo(c,3);button(c,GLFW.GLFW_MOUSE_BUTTON_RIGHT,0,true);});
        step(6,c->moveTo(c,4));
        step(6,c->moveTo(c,5));
        step(6,c->button(c,GLFW.GLFW_MOUSE_BUTTON_RIGHT,0,false));
        step(8,c->{
            int a=count(c,3),b=count(c,4),d=count(c,5),cur=cursor(c).method_7947();
            log(verdict(a==1&&b==1&&d==1&&cur==61)+" right-click drag: chest slots 3/4/5 = "+a+"/"+b+"/"+d+" (want 1/1/1), cursor = "+cur+" (want 61)");
            pickup(c,27);
        });
        // ---- left-click collect: hold 10 logs, sweep over two more stacks of 10
        step(6,c->pickup(c,31));
        step(4,c->{moveTo(c,32);button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,0,true);});
        step(6,c->moveTo(c,33));
        step(6,c->button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,0,false));
        step(8,c->{
            int cur=cursor(c).method_7947(),left=count(c,32)+count(c,33);
            log(verdict(cur==30&&left==0)+" left-click collect: cursor = "+cur+" logs (want 30), left in slots = "+left+" (want 0)");
            pickup(c,10);
        });
        // ---- shift + left sweep over the three cobblestone stacks
        step(6,c->{moveTo(c,28);button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,GLFW.GLFW_MOD_SHIFT,true);});
        step(6,c->moveTo(c,29));
        step(6,c->moveTo(c,30));
        step(6,c->button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,GLFW.GLFW_MOD_SHIFT,false));
        step(8,c->{
            int inChest=0;for(int i=0;i<27;i++)if(stack(c,i).method_31574(class_1802.field_20412))inChest+=count(c,i);
            int left=count(c,28)+count(c,29)+count(c,30);
            log(verdict(inChest==160&&left==0)+" shift-drag: cobblestone in chest = "+inChest+" (want 160), left in inventory = "+left+" (want 0)");
        });
        // ---- scroll wheel: one log out of the chest, then one back in
        step(4,c->{moveTo(c,10);scroll(c,-1);});
        step(12,c->{
            int chest=count(c,10),inv=0;for(int i=27;i<63;i++)if(stack(c,i).method_31574(class_1802.field_8583))inv+=count(c,i);
            log(verdict(chest==29&&inv==1)+" wheel down: chest logs = "+chest+" (want 29), inventory logs = "+inv+" (want 1)");
            scroll(c,1);
        });
        step(12,c->{
            int chest=count(c,10);
            log(verdict(chest==30)+" wheel up: chest logs = "+chest+" (want 30)");
        });
        // ---- shift sweep that starts BETWEEN slots, not on one
        step(4,c->{moveToBackground(c,36);button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,GLFW.GLFW_MOD_SHIFT,true);});
        step(6,c->moveTo(c,36));
        step(6,c->moveTo(c,37));
        step(6,c->moveTo(c,38));
        step(6,c->button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,GLFW.GLFW_MOD_SHIFT,false));
        step(10,c->{
            int left=count(c,36)+count(c,37)+count(c,38),inChest=0;for(int i=0;i<27;i++)if(stack(c,i).method_31574(class_1802.field_8858))inChest+=count(c,i);
            log(verdict(left==0&&inChest==144)+" shift-drag started between slots: sand in chest = "+inChest+" (want 144), left = "+left+" (want 0)");
            pickup(c,41);
        });
        // ---- left-click collect that starts BETWEEN slots
        step(6,c->{moveToBackground(c,36);button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,0,true);});
        step(6,c->moveTo(c,39));
        step(6,c->moveTo(c,40));
        step(6,c->button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,0,false));
        step(10,c->{
            int cur=cursor(c).method_7947(),left=count(c,39)+count(c,40);
            log(verdict(cur==30&&left==0)+" left-click collect started between slots: cursor = "+cur+" gravel (want 30), left = "+left+" (want 0)");
            pickup(c,41);
            shot(c,"chest");
        });
        // ---- the same sweeps in the player's own inventory screen (E)
        step(4,c->{
            c.field_1724.method_7346(); // tells the server the chest is closed
            var server=c.method_1576();var id=c.field_1724.method_5667();
            server.execute(()->{
                var inv=server.method_3760().method_14602(id).method_31548();
                for(int i=9;i<36;i++)inv.method_5447(i,class_1799.field_8037);
                for(int i=1;i<9;i++)inv.method_5447(i,class_1799.field_8037);
                inv.method_5447(9,new class_1799(class_1802.field_20391,64));inv.method_5447(10,new class_1799(class_1802.field_20391,64)); // slots 9, 10
                inv.method_5447(11,new class_1799(class_1802.field_8145,8));inv.method_5447(12,new class_1799(class_1802.field_8145,8));   // slots 11, 12
                inv.method_5447(13,new class_1799(class_1802.field_8145,8));                                                  // slot 13
                var box=new class_1799(class_1802.field_8816);
                box.method_57379(net.minecraft.class_9334.field_49622,net.minecraft.class_9288.method_57493(java.util.List.of(
                    new class_1799(class_1802.field_8477,12),new class_1799(class_1802.field_8463,3),class_1799.field_8037,new class_1799(class_1802.field_8634,16),
                    class_1799.field_8037,class_1799.field_8037,new class_1799(class_1802.field_8288),class_1799.field_8037,class_1799.field_8037,new class_1799(class_1802.field_8281,64))));
                inv.method_5447(17,box);                                                                           // slot 17
            });
        });
        step(10,c->{
            c.method_1507(new net.minecraft.class_490(c.field_1724));
        });
        step(6,c->{var screen=(class_465<?>)c.field_1755;sx=field(screen,"x");sy=field(screen,"y");
            moveTo(c,9);button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,GLFW.GLFW_MOD_SHIFT,true);});
        step(6,c->moveTo(c,10));
        step(6,c->button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,GLFW.GLFW_MOD_SHIFT,false));
        step(10,c->{
            int hotbar=0;for(int i=36;i<45;i++)if(stack(c,i).method_31574(class_1802.field_20391))hotbar+=count(c,i);
            log(verdict(hotbar==128&&count(c,9)+count(c,10)==0)+" inventory screen shift-drag: stone in hotbar = "+hotbar+" (want 128), left = "+(count(c,9)+count(c,10)));
            pickup(c,13);
        });
        step(6,c->{moveTo(c,11);button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,0,true);});
        step(6,c->moveTo(c,12));
        step(6,c->button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,0,false));
        step(10,c->{
            int cur=cursor(c).method_7947();
            log(verdict(cur==24&&count(c,11)+count(c,12)==0)+" inventory screen left-click collect: cursor = "+cur+" flint (want 24), slots 11/12 = "+count(c,11)+"/"+count(c,12));
            pickup(c,13);
        });
        // ---- fast sweep: jump from the first totem straight to the last in one move
        step(4,c->{
            var server=c.method_1576();var id=c.field_1724.method_5667();
            server.execute(()->{var inv=server.method_3760().method_14602(id).method_31548();
                for(int i=1;i<9;i++)inv.method_5447(i,class_1799.field_8037);
                for(int i=27;i<32;i++)inv.method_5447(i,new class_1799(class_1802.field_8288));}); // slots 27..31
        });
        step(10,c->{moveTo(c,27);button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,GLFW.GLFW_MOD_SHIFT,true);});
        step(6,c->moveTo(c,31));
        step(6,c->button(c,GLFW.GLFW_MOUSE_BUTTON_LEFT,GLFW.GLFW_MOD_SHIFT,false));
        step(10,c->{
            int left=0,hotbar=0;for(int i=27;i<32;i++)left+=count(c,i);
            for(int i=36;i<45;i++)if(stack(c,i).method_31574(class_1802.field_8288))hotbar++;
            log(verdict(left==0&&hotbar==5)+" fast shift-sweep over 5 totems: moved to hotbar = "+hotbar+" (want 5), left = "+left+" (want 0)");
        });
        step(6,c->{var cf=ShoreClient.config;cf.shulkerMode=1;cf.shulkerScale=150;cf.shulkerBorderMode=1;moveTo(c,17);});
        step(8,c->shot(c,"shulker"));
        step(2,c->ShoreClient.config.shulkerMode=0);
        step(2,c->{
            c.field_1724.method_7346();
            var chat=c.field_1705.method_1743();ShoreClient.config.filterDuplicates=true;ShoreClient.config.stackStyle=0;
            for(String m:new String[]{"Stack test A","Stack test B","Stack test A","Stack test C","Stack test A"})chat.method_1812(net.minecraft.class_2561.method_43470(m));
        });
        step(4,c->{
            try{
                var f=net.minecraft.class_338.class.getDeclaredField("messages");f.setAccessible(true);
                @SuppressWarnings("unchecked") var msgs=(java.util.List<net.minecraft.class_303>)f.get(c.field_1705.method_1743());
                var v=net.minecraft.class_338.class.getDeclaredField("visibleMessages");v.setAccessible(true);
                @SuppressWarnings("unchecked") var vis=(java.util.List<net.minecraft.class_303.class_7590>)v.get(c.field_1705.method_1743());
                long aCount=msgs.stream().filter(m->m.comp_893().getString().contains("Stack test A")).count();
                String newest=msgs.getFirst().comp_893().getString(),second=msgs.get(1).comp_893().getString(),third=msgs.get(2).comp_893().getString();
                long groups=vis.stream().filter(net.minecraft.class_303.class_7590::comp_898).count();
                boolean ok=aCount==1&&newest.endsWith("Stack test A [x3]")&&second.endsWith("Stack test C")&&third.endsWith("Stack test B")&&groups==msgs.size();
                log(verdict(ok)+" chat stacking: newest = \""+newest+"\", then \""+second+"\", \""+third+"\"; copies of A = "+aCount+" (want 1); visible groups "+groups+" = messages "+msgs.size());
            }catch(ReflectiveOperationException e){log("FAIL chat stacking: "+e);}
            c.method_1507(new net.minecraft.class_408("",false));
        });
        step(8,c->shot(c,"chat"));
        // ---- mentions: someone else saying your name lights the line up; your own chat does not
        step(2,c->{
            ShoreClient.config.mentionHighlight=true;ShoreClient.config.mentionColor=0;
            String me=c.field_1724.method_5477().getString();
            var chat=c.field_1705.method_1743();
            chat.method_1812(net.minecraft.class_2561.method_43470("<Steve> hey "+me+" want to duel?"));
            chat.method_1812(net.minecraft.class_2561.method_43470("<"+me+"> sure, meet at spawn"));
            chat.method_1812(net.minecraft.class_2561.method_43470("<Alex> nice weather today"));
        });
        step(4,c->{
            try{
                var f=net.minecraft.class_338.class.getDeclaredField("messages");f.setAccessible(true);
                @SuppressWarnings("unchecked") var msgs=(java.util.List<net.minecraft.class_303>)f.get(c.field_1705.method_1743());
                var m=net.minecraft.class_338.class.getDeclaredField("SHORE_MENTIONS");m.setAccessible(true);
                @SuppressWarnings("unchecked") var marked=(java.util.Set<net.minecraft.class_303>)m.get(null);
                boolean other=marked.contains(msgs.get(2)),own=marked.contains(msgs.get(1)),none=marked.contains(msgs.get(0));
                log(verdict(other&&!own&&!none)+" mentions: \""+msgs.get(2).comp_893().getString()+"\" highlighted = "+other+" (want true); own message = "+own+" (want false); unrelated = "+none+" (want false)");
            }catch(ReflectiveOperationException e){log("FAIL mentions: "+e);}
            c.method_1507(new net.minecraft.class_408("",false));
        });
        step(8,c->shot(c,"mentions"));
        // ---- PvP HUD: items, effects, and two hits on a pig
        step(2,c->{
            c.method_1507(null);
            var cfg=ShoreClient.config;cfg.keystrokes=true;cfg.targetHud=true;cfg.potionHud=true;cfg.itemCounter=true;
            var server=c.method_1576();var src=server.method_3739();String me=c.field_1724.method_5477().getString();
            server.execute(()->{
                for(String cmd:new String[]{"give "+me+" totem_of_undying 3","give "+me+" ender_pearl 16","give "+me+" golden_apple 8",
                        "effect give "+me+" speed 120 1","effect give "+me+" strength 90 0",
                        "execute at "+me+" run summon pig ^ ^ ^2 {NoAI:1b,Invulnerable:1b}"})
                    server.method_3734().method_44252(src,cmd);
            });
        });
        step(20,c->{
            var pigs=c.field_1687.method_8390(net.minecraft.class_1452.class,c.field_1724.method_5829().method_1014(6),p->true);
            if(pigs.isEmpty()){log("FAIL pvp: no pig to hit");return;}
            c.field_1761.method_2918(c.field_1724,pigs.getFirst());
        });
        step(12,c->{
            var pigs=c.field_1687.method_8390(net.minecraft.class_1452.class,c.field_1724.method_5829().method_1014(6),p->true);
            if(!pigs.isEmpty())c.field_1761.method_2918(c.field_1724,pigs.getFirst());
        });
        step(6,c->{
            var t=ShorePvp.target();
            log(verdict(t!=null)+" target HUD: "+(t==null?"none":t.method_5477().getString()));
        });
        step(6,c->shot(c,"pvp_hud"));
        // ---- your own crosshair picture, and your own item in the item counter
        step(2,c->{
            try{
                var img=new java.awt.image.BufferedImage(32,32,java.awt.image.BufferedImage.TYPE_INT_ARGB);
                var g=img.createGraphics();g.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING,java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(new java.awt.Color(255,60,60));g.setStroke(new java.awt.BasicStroke(3));g.drawOval(4,4,24,24);g.fillOval(14,14,4,4);g.dispose();
                var file=c.field_1697.toPath().resolve("selftest_crosshair.png");javax.imageio.ImageIO.write(img,"png",file.toFile());
                var cf=ShoreClient.config;cf.crosshair=true;cf.crosshairMode=1;cf.crosshairImageSize=24;
                cf.crosshairImage=ShoreHud.CrosshairImage.importFile(file);
                cf.itemsCustom=new java.util.ArrayList<>(java.util.List.of("cobweb"));
                var server=c.method_1576();String me=c.field_1724.method_5477().getString();
                server.execute(()->server.method_3734().method_44252(server.method_3739(),"give "+me+" cobweb 5"));
            }catch(Exception e){log("FAIL crosshair image setup: "+e);}
        });
        step(10,c->{
            boolean loaded=ShoreHud.CrosshairImage.texture(ShoreClient.config.crosshairImage)!=null;
            log(verdict(loaded)+" crosshair image loaded from "+ShoreClient.config.crosshairImage);
            shot(c,"crosshair_image");
            var cf=ShoreClient.config;cf.crosshairMode=0;cf.crosshairColor=1;cf.crosshairDot=true;cf.crosshairLength=6;cf.crosshairGap=3;
        });
        step(6,c->shot(c,"crosshair_shape"));
        // ---- zoom must never change the mouse sensitivity setting
        step(2,c->{zoomSens=c.field_1690.method_42495().method_41753();ShoreClient.config.zoomEnabled=true;ShoreClient.config.zoomToggle=false;ShoreTools.zoomKey.method_23481(true);});
        step(6,c->{zoomScaleWhile=ShoreTools.lookScale();zoomSensWhile=c.field_1690.method_42495().method_41753();ShoreTools.zoomKey.method_23481(false);});
        step(6,c->{
            double after=c.field_1690.method_42495().method_41753();
            boolean ok=zoomScaleWhile<1&&zoomSensWhile==zoomSens&&after==zoomSens&&ShoreTools.lookScale()==1;
            log(verdict(ok)+" zoom sensitivity: setting before/while/after = "+zoomSens+"/"+zoomSensWhile+"/"+after+", turn scale while zoomed = "+String.format(Locale.ROOT,"%.2f",zoomScaleWhile)+" (want < 1), after = "+ShoreTools.lookScale());
        });
        step(2,c->{c.method_1507(null);ShoreClient.config.hudSizes.put("fps",200);ShoreClient.config.cps=true;ShoreClient.config.crosshair=true;ShoreClient.config.crosshairColor=1;ShoreClient.config.crosshairDot=true;});
        step(20,c->shot(c,"hud"));
        step(2,c->{log("World tests done");finish(c);});
    }
    private static String verdict(boolean ok){return ok?"PASS":"FAIL";}
    private static void pickup(class_310 c,int id){c.field_1761.method_2906(((class_465<?>)c.field_1755).method_17577().field_7763,id,0,class_1713.field_7790,c.field_1724);}
    // Real input path: the same private Mouse callbacks GLFW invokes.
    private static void moveTo(class_310 c,int slotId){
        class_1735 s=slot(c,slotId);var w=c.method_22683();
        double gx=sx+s.field_7873+8,gy=sy+s.field_7872+8;
        invoke(c,"onCursorPos",new Class<?>[]{long.class,double.class,double.class},w.method_4490(),gx*w.method_4480()/w.method_4486(),gy*w.method_4507()/w.method_4502());
    }
    /** A point on the inventory background just left of a slot in the first column (on no slot). */
    private static void moveToBackground(class_310 c,int slotId){
        class_1735 s=slot(c,slotId);var w=c.method_22683();
        double gx=sx+s.field_7873-3,gy=sy+s.field_7872+8;
        invoke(c,"onCursorPos",new Class<?>[]{long.class,double.class,double.class},w.method_4490(),gx*w.method_4480()/w.method_4486(),gy*w.method_4507()/w.method_4502());
    }
    private static void button(class_310 c,int button,int mods,boolean press){
        invoke(c,"onMouseButton",new Class<?>[]{long.class,class_11910.class,int.class},c.method_22683().method_4490(),new class_11910(button,mods),press?GLFW.GLFW_PRESS:GLFW.GLFW_RELEASE);
    }
    private static void scroll(class_310 c,double amount){
        invoke(c,"onMouseScroll",new Class<?>[]{long.class,double.class,double.class},c.method_22683().method_4490(),0.0,amount);
    }
    private static void invoke(class_310 c,String name,Class<?>[] types,Object... args){
        try{var m=net.minecraft.class_312.class.getDeclaredMethod(name,types);m.setAccessible(true);m.invoke(c.field_1729,args);}
        catch(ReflectiveOperationException e){throw new IllegalStateException(name,e);}
    }
    private static class_1735 slot(class_310 c,int id){return ((class_465<?>)c.field_1755).method_17577().method_7611(id);}
    private static class_1799 stack(class_310 c,int id){return slot(c,id).method_7677();}
    private static int count(class_310 c,int id){return stack(c,id).method_7947();}
    private static class_1799 cursor(class_310 c){return ((class_465<?>)c.field_1755).method_17577().method_34255();}
    private static class_11909 click(class_310 c,int slotId,int button,int mods){
        class_1735 s=slot(c,slotId);return new class_11909(sx+s.field_7873+8,sy+s.field_7872+8,new class_11910(button,mods));
    }
    private static int field(Object o,String name){
        // Dev-only (named mappings): HandledScreen keeps its origin in protected int fields x and y.
        try{var f=class_465.class.getDeclaredField(name);f.setAccessible(true);return f.getInt(o);}
        catch(ReflectiveOperationException e){throw new IllegalStateException(e);}
    }
}

